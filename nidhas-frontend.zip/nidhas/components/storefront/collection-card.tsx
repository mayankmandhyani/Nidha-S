import Link from "next/link";
import Image from "next/image";
import type { Collection } from "@/types/database";

export function CollectionCard({ collection }: { collection: Collection }) {
  return (
    <Link
      href={`/collections/${collection.slug}`}
      className="group relative block aspect-[4/5] overflow-hidden"
    >
      {collection.cover_image_path && (
        <Image
          src={collection.cover_image_path}
          alt={collection.name}
          fill
          className="object-cover transition-transform duration-700 group-hover:scale-105"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-espresso/60 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-6">
        <h3 className="font-display text-2xl text-ivory">{collection.name}</h3>
      </div>
    </Link>
  );
}
