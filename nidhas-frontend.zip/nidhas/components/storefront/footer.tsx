import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-mist mt-24">
      <div className="max-w-[1440px] mx-auto px-6 md:px-12 lg:px-20 py-16 grid grid-cols-2 md:grid-cols-4 gap-10">
        <div>
          <p className="text-xs uppercase tracking-label text-brown mb-4">Shop</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/collections/kurtis" className="hover:text-brown">Kurtis</Link></li>
            <li><Link href="/collections/salwar-suits" className="hover:text-brown">Salwar Suits</Link></li>
            <li><Link href="/collections/dress-materials" className="hover:text-brown">Dress Materials</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-xs uppercase tracking-label text-brown mb-4">Collections</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/new-arrivals" className="hover:text-brown">New Arrivals</Link></li>
            <li><Link href="/collections/festive-collection" className="hover:text-brown">Festive Collection</Link></li>
          </ul>
        </div>
        <div>
          <p className="text-xs uppercase tracking-label text-brown mb-4">Contact</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/contact" className="hover:text-brown">Enquire</Link></li>
            <li className="text-espresso/60">WhatsApp available on every product</li>
          </ul>
        </div>
        <div>
          <p className="text-xs uppercase tracking-label text-brown mb-4">Nidhas</p>
          <p className="text-sm text-espresso/60">
            Hand-finished ethnic wear, made in small batches.
          </p>
        </div>
      </div>
      <div className="border-t border-mist py-6 text-center text-xs text-espresso/50">
        © {new Date().getFullYear()} Nidhas. All rights reserved.
      </div>
    </footer>
  );
}
