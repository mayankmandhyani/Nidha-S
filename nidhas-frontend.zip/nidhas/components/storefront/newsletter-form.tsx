"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email) return;
    setSubmitting(true);
    // Placeholder — no real newsletter backend during the mock-data phase.
    await new Promise((r) => setTimeout(r, 400));
    toast.success("You're on the list.");
    setEmail("");
    setSubmitting(false);
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-4 max-w-sm mx-auto">
      <Input
        type="email"
        required
        placeholder="Your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="flex-1"
      />
      <Button type="submit" disabled={submitting}>
        {submitting ? "..." : "Subscribe"}
      </Button>
    </form>
  );
}
