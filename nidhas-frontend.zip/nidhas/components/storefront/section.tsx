import { cn } from "@/lib/utils/cn";

export function FullBleedSection({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return <section className={cn("w-full", className)}>{children}</section>;
}

export function ContainedSection({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "max-w-[1440px] mx-auto px-6 md:px-12 lg:px-20 py-24 md:py-40",
        className
      )}
    >
      {children}
    </section>
  );
}

export function SplitSection({
  image,
  children,
  imageFirst = true,
}: {
  image: React.ReactNode;
  children: React.ReactNode;
  imageFirst?: boolean;
}) {
  return (
    <div
      className={cn(
        "grid md:grid-cols-[3fr_2fr] gap-8 md:gap-16 items-center",
        !imageFirst && "md:[direction:rtl]"
      )}
    >
      <div className={!imageFirst ? "[direction:ltr]" : ""}>{image}</div>
      <div className="[direction:ltr] space-y-6">{children}</div>
    </div>
  );
}
