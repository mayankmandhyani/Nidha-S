"use client";

import { useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils/cn";
import type { ProductMedia } from "@/types/database";

export function ProductGallery({
  media,
  productName,
}: {
  media: ProductMedia[];
  productName: string;
}) {
  const [activeIndex, setActiveIndex] = useState(0);
  const active = media[activeIndex];

  if (media.length === 0) {
    return (
      <div className="aspect-[3/4] bg-sand flex items-center justify-center text-espresso/30 text-xs uppercase tracking-label">
        No image
      </div>
    );
  }

  return (
    <div>
      <div className="aspect-[3/4] relative overflow-hidden bg-sand">
        <AnimatePresence mode="wait">
          <motion.div
            key={active.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0"
          >
            <Image
              src={active.storage_path}
              alt={active.alt_text ?? productName}
              fill
              priority
              className="object-cover"
            />
          </motion.div>
        </AnimatePresence>
      </div>

      {media.length > 1 && (
        <div className="mt-4 grid grid-cols-4 gap-3">
          {media.map((m, i) => (
            <button
              key={m.id}
              onClick={() => setActiveIndex(i)}
              className={cn(
                "aspect-square relative overflow-hidden bg-sand transition-opacity",
                i === activeIndex ? "opacity-100 ring-1 ring-espresso" : "opacity-60 hover:opacity-100"
              )}
              aria-label={`View image ${i + 1}`}
            >
              <Image src={m.storage_path} alt={m.alt_text ?? productName} fill className="object-cover" />
            </button>
          ))}
        </div>
      )}
      {active.caption && (
        <p className="mt-2 text-xs text-espresso/50">{active.caption}</p>
      )}
    </div>
  );
}
