import type { Testimonial } from "@/types/database";

export function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  return (
    <div className="border-t border-mist pt-6">
      <p className="font-display italic text-xl md:text-2xl leading-snug">
        &ldquo;{testimonial.quote}&rdquo;
      </p>
      <p className="mt-4 text-xs uppercase tracking-label text-brown">
        {testimonial.customer_name}
        {testimonial.location ? ` · ${testimonial.location}` : ""}
      </p>
    </div>
  );
}
