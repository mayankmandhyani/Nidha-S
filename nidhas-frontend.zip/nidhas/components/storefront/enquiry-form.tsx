"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { enquirySchema, type EnquiryInput } from "@/lib/validators/enquiry.schema";
import { EnquiryService } from "@/lib/services/enquiry.service";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

export function EnquiryForm({
  productId,
  productName,
}: {
  productId?: string;
  productName?: string;
}) {
  const form = useForm<EnquiryInput>({
    resolver: zodResolver(enquirySchema),
    defaultValues: {
      customer_name: "",
      phone: "",
      email: "",
      message: productName ? `I'd like to know more about ${productName}.` : "",
      product_id: productId ?? null,
    },
  });

  const mutation = useMutation({
    mutationFn: (data: EnquiryInput) =>
      EnquiryService.create(undefined, {
        ...data,
        email: data.email || null,
        message: data.message || null,
        product_id: data.product_id ?? null,
      }),
    onSuccess: () => {
      toast.success("Enquiry sent — we'll be in touch shortly.");
      form.reset();
    },
    onError: () => {
      toast.error("Something went wrong sending your enquiry. Please try again.");
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-5">
        <FormField
          control={form.control}
          name="customer_name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="phone"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Phone</FormLabel>
              <FormControl>
                <Input type="tel" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email (optional)</FormLabel>
              <FormControl>
                <Input type="email" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Message</FormLabel>
              <FormControl>
                <Textarea {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" disabled={mutation.isPending}>
          {mutation.isPending ? "Sending..." : "Send Enquiry"}
        </Button>
      </form>
    </Form>
  );
}
