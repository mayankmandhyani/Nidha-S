import Link from "next/link";
import Image from "next/image";
import type { Product, ProductMedia } from "@/types/database";

interface ProductCardProps {
  product: Product;
  media?: ProductMedia;
}

export function ProductCard({ product, media }: ProductCardProps) {
  return (
    <Link href={`/products/${product.slug}`} className="group block">
      <div className="aspect-[3/4] overflow-hidden bg-sand">
        {media ? (
          <Image
            src={media.storage_path}
            alt={media.alt_text ?? product.name}
            width={600}
            height={800}
            className="h-full w-full object-cover transition-transform duration-500 ease-[cubic-bezier(0.65,0,0.35,1)] group-hover:scale-105"
          />
        ) : (
          <div className="h-full w-full flex items-center justify-center text-espresso/30 text-xs uppercase tracking-label">
            No image
          </div>
        )}
      </div>
      <div className="mt-3 space-y-1">
        <h3 className="font-display text-lg group-hover:text-brown transition-colors">
          {product.name}
        </h3>
        {product.price !== null ? (
          <p className="text-sm text-espresso/70">
            ₹{product.price.toLocaleString("en-IN")}
          </p>
        ) : (
          <p className="text-xs uppercase tracking-label text-brown">Enquire for price</p>
        )}
      </div>
    </Link>
  );
}

export function ProductCardSkeleton() {
  return (
    <div>
      <div className="aspect-[3/4] bg-sand animate-pulse motion-reduce:animate-none" />
      <div className="mt-3 space-y-2">
        <div className="h-4 w-2/3 bg-sand animate-pulse motion-reduce:animate-none" />
        <div className="h-3 w-1/3 bg-sand animate-pulse motion-reduce:animate-none" />
      </div>
    </div>
  );
}
