import { cn } from "@/lib/utils/cn";

export function Badge({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center border border-mist px-3 py-1 text-xs uppercase tracking-label text-brown",
        className
      )}
    >
      {children}
    </span>
  );
}
