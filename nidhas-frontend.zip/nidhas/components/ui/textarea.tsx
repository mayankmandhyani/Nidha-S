import * as React from "react";
import { cn } from "@/lib/utils/cn";

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  variant?: "underline" | "boxed";
}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, variant = "underline", ...props }, ref) => {
    return (
      <textarea
        ref={ref}
        className={cn(
          "flex min-h-24 w-full bg-transparent text-base transition-colors placeholder:text-espresso/40 focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50",
          variant === "underline" &&
            "border-0 border-b border-mist px-0 py-2 focus-visible:border-espresso",
          variant === "boxed" &&
            "border border-mist bg-ivory px-3 py-2 focus-visible:border-espresso",
          className
        )}
        {...props}
      />
    );
  }
);
Textarea.displayName = "Textarea";

export { Textarea };
