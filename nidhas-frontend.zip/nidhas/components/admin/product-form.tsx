"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { productSchema, type ProductInput } from "@/lib/validators/product.schema";
import { useCreateProduct, useUpdateProduct } from "@/lib/hooks/use-products";
import { useCategories } from "@/lib/hooks/use-categories";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormDescription,
  FormMessage,
} from "@/components/ui/form";
import type { Product } from "@/types/database";

export function ProductForm({ existingProduct }: { existingProduct?: Product }) {
  const router = useRouter();
  const { data: categories, isLoading: categoriesLoading } = useCategories();
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const isEditing = !!existingProduct;

  const form = useForm<ProductInput>({
    resolver: zodResolver(productSchema),
    defaultValues: existingProduct
      ? {
          category_id: existingProduct.category_id,
          name: existingProduct.name,
          slug: existingProduct.slug,
          description: existingProduct.description ?? "",
          fabric_details: existingProduct.fabric_details ?? "",
          price: existingProduct.price ?? undefined,
          is_active: existingProduct.is_active,
          is_featured: existingProduct.is_featured,
          seo_title: existingProduct.seo_title ?? "",
          seo_description: existingProduct.seo_description ?? "",
        }
      : {
          category_id: "",
          name: "",
          slug: "",
          description: "",
          fabric_details: "",
          price: undefined,
          is_active: true,
          is_featured: false,
          seo_title: "",
          seo_description: "",
        },
  });

  function onSubmit(values: ProductInput) {
    const payload = {
      ...values,
      description: values.description || null,
      fabric_details: values.fabric_details || null,
      price: values.price ?? null,
      seo_title: values.seo_title || null,
      seo_description: values.seo_description || null,
    };

    if (isEditing) {
      updateProduct.mutate(
        { id: existingProduct.id, data: payload },
        {
          onSuccess: () => {
            toast.success("Product updated.");
            router.push("/admin/products");
          },
          onError: () => toast.error("Couldn't save changes. Please try again."),
        }
      );
    } else {
      createProduct.mutate(payload, {
        onSuccess: () => {
          toast.success("Product created.");
          router.push("/admin/products");
        },
        onError: () => toast.error("Couldn't create the product. Please try again."),
      });
    }
  }

  const isSubmitting = createProduct.isPending || updateProduct.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 max-w-2xl">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input variant="boxed" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="slug"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Slug</FormLabel>
              <FormControl>
                <Input variant="boxed" {...field} />
              </FormControl>
              <FormDescription>Used in the product URL. Lowercase, hyphens only.</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="category_id"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Category</FormLabel>
              <FormControl>
                <select
                  {...field}
                  disabled={categoriesLoading}
                  className="w-full border border-mist bg-ivory px-3 py-2 text-sm focus-visible:outline-none focus-visible:border-espresso"
                >
                  <option value="">Select a category</option>
                  {categories?.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="price"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Price (₹, optional)</FormLabel>
              <FormControl>
                <Input
                  variant="boxed"
                  type="number"
                  {...field}
                  value={field.value ?? ""}
                  onChange={(e) => field.onChange(e.target.value === "" ? null : e.target.value)}
                />
              </FormControl>
              <FormDescription>
                Leave blank to show &ldquo;Enquire for price&rdquo; on the storefront instead.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea variant="boxed" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="fabric_details"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Fabric Details</FormLabel>
              <FormControl>
                <Input variant="boxed" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex gap-8">
          <FormField
            control={form.control}
            name="is_active"
            render={({ field }) => (
              <FormItem className="flex items-center gap-2 space-y-0">
                <FormControl>
                  <input
                    type="checkbox"
                    checked={field.value}
                    onChange={(e) => field.onChange(e.target.checked)}
                  />
                </FormControl>
                <FormLabel className="!m-0">Active (visible on storefront)</FormLabel>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="is_featured"
            render={({ field }) => (
              <FormItem className="flex items-center gap-2 space-y-0">
                <FormControl>
                  <input
                    type="checkbox"
                    checked={field.value}
                    onChange={(e) => field.onChange(e.target.checked)}
                  />
                </FormControl>
                <FormLabel className="!m-0">Featured</FormLabel>
              </FormItem>
            )}
          />
        </div>

        <details className="border border-mist p-4">
          <summary className="text-xs uppercase tracking-label text-brown cursor-pointer">
            SEO (optional overrides)
          </summary>
          <div className="mt-4 space-y-4">
            <FormField
              control={form.control}
              name="seo_title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SEO Title</FormLabel>
                  <FormControl>
                    <Input variant="boxed" {...field} />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="seo_description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>SEO Description</FormLabel>
                  <FormControl>
                    <Textarea variant="boxed" {...field} />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>
        </details>

        <div className="flex gap-4 pt-4">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : isEditing ? "Save Changes" : "Create Product"}
          </Button>
          <Button type="button" variant="secondary" onClick={() => router.push("/admin/products")}>
            Cancel
          </Button>
        </div>
      </form>
    </Form>
  );
}
