"use client";

import { useSignOut } from "@/lib/hooks/use-auth";
import { Button } from "@/components/ui/button";

export function LogoutButton() {
  const signOut = useSignOut();

  return (
    <Button
      variant="secondary"
      size="sm"
      onClick={() => signOut.mutate()}
      disabled={signOut.isPending}
    >
      {signOut.isPending ? "Signing out..." : "Sign out"}
    </Button>
  );
}
