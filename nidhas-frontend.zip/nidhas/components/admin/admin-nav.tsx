"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils/cn";

const LINKS = [
  { href: "/admin/dashboard", label: "Dashboard" },
  { href: "/admin/products", label: "Products" },
  { href: "/admin/categories", label: "Categories" },
  { href: "/admin/collections", label: "Collections" },
  { href: "/admin/hero-banner", label: "Hero Banner" },
  { href: "/admin/homepage-content", label: "Homepage Content" },
  { href: "/admin/testimonials", label: "Testimonials" },
  { href: "/admin/enquiries", label: "Enquiries" },
];

export function AdminNav() {
  const pathname = usePathname();
  return (
    <nav className="space-y-1">
      {LINKS.map((link) => (
        <Link
          key={link.href}
          href={link.href}
          className={cn(
            "block px-4 py-2 text-sm border-l-2 transition-colors",
            pathname.startsWith(link.href)
              ? "border-espresso bg-sand text-espresso"
              : "border-transparent text-espresso/60 hover:text-espresso hover:bg-sand/50"
          )}
        >
          {link.label}
        </Link>
      ))}
    </nav>
  );
}
