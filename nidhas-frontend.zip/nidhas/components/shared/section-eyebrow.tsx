export function SectionEyebrow({ children }: { children: React.ReactNode }) {
  return <p className="text-xs uppercase tracking-label text-brown">{children}</p>;
}
