import { Button } from "@/components/ui/button";

export function EmptyState({
  heading,
  message,
  actionLabel,
  onAction,
}: {
  heading: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex flex-col items-center text-center py-24 space-y-4">
      <h3 className="font-display text-2xl">{heading}</h3>
      <p className="text-sm text-espresso/60 max-w-sm">{message}</p>
      {actionLabel && onAction && (
        <Button variant="secondary" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
}
