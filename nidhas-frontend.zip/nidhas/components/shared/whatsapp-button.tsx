import { Button } from "@/components/ui/button";

const WHATSAPP_NUMBER = "919999999999"; // placeholder — replaced with the real business number in config/brand.ts

export function WhatsAppButton({
  message = "Hi, I'd like to know more about Nidhas.",
  className,
  children = "Chat on WhatsApp",
}: {
  message?: string;
  className?: string;
  children?: React.ReactNode;
}) {
  const href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  return (
    <Button asChild variant="secondary" className={className}>
      <a href={href} target="_blank" rel="noopener noreferrer">
        {children}
      </a>
    </Button>
  );
}
