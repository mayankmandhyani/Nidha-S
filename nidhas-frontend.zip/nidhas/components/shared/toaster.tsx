"use client";

import { Toaster as Sonner } from "sonner";

export function Toaster() {
  return (
    <Sonner
      position="bottom-right"
      toastOptions={{
        style: {
          background: "#FAF6EF",
          color: "#2B2420",
          border: "1px solid #DDD3C4",
          borderRadius: "0.125rem",
          boxShadow: "0 8px 30px -8px rgb(43 36 32 / 0.12)",
          fontFamily: "var(--font-body)",
          fontSize: "0.875rem",
        },
      }}
    />
  );
}
