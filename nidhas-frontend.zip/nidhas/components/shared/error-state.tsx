import { Button } from "@/components/ui/button";

export function ErrorState({
  heading = "Something went wrong loading this page",
  message = "Please try again, or contact us on WhatsApp if the problem continues.",
  onRetry,
}: {
  heading?: string;
  message?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="flex flex-col items-center text-center py-24 space-y-4">
      <h3 className="font-display text-2xl">{heading}</h3>
      <p className="text-sm text-espresso/60 max-w-sm">{message}</p>
      {onRetry && <Button variant="primary" onClick={onRetry}>Try again</Button>}
    </div>
  );
}
