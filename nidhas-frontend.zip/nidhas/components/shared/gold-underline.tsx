"use client";

import { motion } from "framer-motion";
import { useReducedMotion } from "@/lib/hooks/use-reduced-motion";

// Optional decorative element, not a system dependency — see docs/journal.md
// Phase 7 refinement. Safe to use or omit per placement.
export function GoldUnderline({ className = "" }: { className?: string }) {
  const reduced = useReducedMotion();

  if (reduced) {
    return <span className={`block h-px w-12 bg-gold ${className}`} />;
  }

  return (
    <motion.span
      initial={{ scaleX: 0 }}
      whileInView={{ scaleX: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, ease: [0.65, 0, 0.35, 1] }}
      className={`block h-px w-12 origin-left bg-gold ${className}`}
    />
  );
}
