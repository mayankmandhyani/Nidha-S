# Nidhas

Premium women's ethnic fashion catalogue — client project, frontend-first build against mock data. No Supabase integration yet; see `PROJECT-STATUS.md` for exactly what's built vs. deferred.

## Stack

Next.js 16 (App Router, Turbopack) · React 19 · TypeScript (strict) · Tailwind CSS v4 · Framer Motion · shadcn-style components (hand-built, re-themed) · TanStack Query · React Hook Form + Zod · sonner (toasts)

**Note on Tailwind v4:** design tokens live in `app/globals.css` via the `@theme` directive — there is no `tailwind.config.ts`. This is current Tailwind v4 convention (CSS-first config), not a deviation from the design system spec — the same color/type/spacing tokens are all there, just declared in CSS instead of a JS config file.

**Note on `proxy.ts`:** Next.js 16 renamed the `middleware.ts` file convention to `proxy.ts` (an old-named file is silently ignored, not an error). Route protection for `/admin/*` lives in `proxy.ts` at the project root.

## Local Development

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Admin Access (mock, demo-only)

`http://localhost:3000/admin/login`

- Email: anything (not validated against a real user store)
- Password: `nidhas-demo`

This is a development-only gate with zero real security value — there's no real backend yet to protect. See `PROJECT-STATUS.md` and `lib/services/auth.service.ts` for why, and what replaces it in backend integration.

## Mock Data

All content (products, categories, collections, testimonials, enquiries, hero banner, homepage content blocks) is seeded from `lib/mock-data/seed.ts` and persisted to `localStorage` in the browser, so admin edits are visible on the storefront within the same session. **Known limitation:** Server Components have no `localStorage`, so a hard refresh on a server-rendered page falls back to the original seed data rather than showing browser-side admin edits. This resolves automatically once real Supabase integration replaces the mock store — not a bug to chase down now.

To reset the mock data to its original seed state, clear `localStorage` for the site (or run `localStorage.removeItem('nidhas-mock-db')` in the browser console).

## Build

```bash
npm run build
```

Verified clean — zero TypeScript errors, zero ESLint errors, all 19 routes build successfully.

## Deployment

Push to GitHub, then import the repository in Vercel. No environment variables are required for this phase — `.env.local.example` lists the Supabase variables that get filled in during backend integration, not before.

## Documentation

- `PROJECT-STATUS.md` — what's built, what's deferred, verification results
- `docs/` — architecture, folder structure, and database design reference (from the planning phase; database schema execution is deferred, but the design itself is finalized)
