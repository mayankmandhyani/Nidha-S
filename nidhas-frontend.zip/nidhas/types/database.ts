// Hand-written now, matching docs/database.md exactly. Regenerated via
// `supabase gen types typescript` during Phase 15 — expected to match closely
// since the schema was finalized, not guessed.

export interface Product {
  id: string;
  category_id: string;
  name: string;
  slug: string;
  description: string | null;
  fabric_details: string | null;
  price: number | null;
  is_active: boolean;
  is_featured: boolean;
  seo_title: string | null;
  seo_description: string | null;
  deleted_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Collection {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  cover_image_path: string | null;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProductCollection {
  product_id: string;
  collection_id: string;
  created_at: string;
}

export interface ProductVariant {
  id: string;
  product_id: string;
  size: string | null;
  color: string | null;
  sku: string | null;
  stock_quantity: number | null;
  price_override: number | null;
  created_at: string;
  updated_at: string;
}

export interface ProductMedia {
  id: string;
  product_id: string;
  media_type: "image" | "video" | "three_sixty";
  storage_path: string;
  alt_text: string | null;
  caption: string | null;
  display_order: number;
  is_primary: boolean;
  created_at: string;
}

export interface Testimonial {
  id: string;
  customer_name: string;
  location: string | null;
  quote: string;
  photo_path: string | null;
  rating: number | null;
  is_published: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface Enquiry {
  id: string;
  product_id: string | null;
  customer_name: string;
  phone: string;
  email: string | null;
  message: string | null;
  status: "new" | "contacted" | "closed";
  created_at: string;
  updated_at: string;
}

export interface HeroBanner {
  id: string;
  headline: string;
  subheadline: string | null;
  cta_text: string | null;
  cta_link: string | null;
  open_in_new_tab: boolean;
  media_path: string | null;
  media_type: "image" | "video";
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ContentBlock {
  id: string;
  block_key: string;
  title: string | null;
  body: string | null;
  image_path: string | null;
  display_order: number;
  is_published: boolean;
  created_at: string;
  updated_at: string;
}

export interface Profile {
  id: string;
  full_name: string | null;
  role: "admin" | "customer";
  created_at: string;
  updated_at: string;
}

// Convenience composite type used by product-detail views —
// not a database table, assembled by the service layer.
export interface ProductWithMedia extends Product {
  media: ProductMedia[];
  variants: ProductVariant[];
  category: Category;
}
