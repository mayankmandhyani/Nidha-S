# Nidhas — Phase 2: Folder Structure (v3, final)

## Confirmed stack
Next.js (App Router) · TypeScript · Tailwind CSS · Framer Motion · GSAP · shadcn/ui · TanStack Query · React Hook Form · Zod · Supabase (Postgres/Auth/Storage) · Vercel

---

## 1. Core architectural rules

**Server Components vs. TanStack Query.** Server Components own all initial rendering, SEO, metadata generation, and first-page data fetching. TanStack Query is scoped to client-side interactivity only — admin CRUD, optimistic updates, cache invalidation, post-hydration state. No duplicate fetching between the two.

**Services are client-agnostic.** All Supabase data access lives in `lib/services/`, one file per entity. Every function takes a Supabase client instance as its first parameter — never imported internally:

```
ProductService.getBySlug(client, slug)
ProductService.create(client, data)
```

Server Components pass the server client. TanStack Query hooks (`lib/hooks/`) pass the browser client. One set of query logic per entity, boundary preserved.

**`content/` is a migration staging ground, not a permanent parallel store.** Static copy lives in `content/` for v1 launch speed. The moment a piece of content gets its own admin screen in Phase 10 (e.g. "Manage Homepage Content," "Manage Testimonials"), it moves into Supabase via the matching Service, and the hardcoded `content/` value is deleted — not kept as a fallback. Two sources of truth for the same text is exactly the kind of thing that causes an admin edit to silently do nothing because the component never got rewired.

---

## 2. Full folder structure

```
nidhas/
├── app/
│   ├── (storefront)/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── collections/
│   │   │   ├── page.tsx
│   │   │   └── [slug]/page.tsx
│   │   ├── products/
│   │   │   └── [slug]/page.tsx         # generateMetadata → per-product OG tags
│   │   ├── new-arrivals/page.tsx
│   │   ├── about/page.tsx
│   │   └── contact/page.tsx
│   │
│   ├── admin/
│   │   ├── layout.tsx
│   │   ├── login/page.tsx
│   │   ├── dashboard/page.tsx
│   │   ├── products/
│   │   │   ├── page.tsx
│   │   │   ├── new/page.tsx
│   │   │   └── [id]/edit/page.tsx
│   │   ├── categories/page.tsx
│   │   ├── collections/page.tsx
│   │   ├── homepage-content/page.tsx
│   │   ├── hero-banner/page.tsx
│   │   ├── testimonials/page.tsx
│   │   └── enquiries/page.tsx
│   │
│   ├── api/                            # minimal — future webhook handlers live here
│   ├── layout.tsx
│   └── globals.css
│
├── components/
│   ├── ui/                             # shadcn primitives
│   ├── storefront/                     # heavily custom-styled brand components
│   ├── admin/
│   └── shared/                         # Logo, WhatsAppButton, LoadingSpinner
│
├── lib/
│   ├── supabase/
│   │   ├── client.ts                   # browser client factory
│   │   ├── server.ts                   # server client factory
│   │   └── middleware.ts
│   ├── services/                       # ALL Supabase data access — client-agnostic (DI)
│   │   ├── product.service.ts
│   │   ├── collection.service.ts
│   │   ├── enquiry.service.ts
│   │   └── testimonial.service.ts
│   ├── hooks/                          # TanStack Query hooks — wrap services, browser client
│   ├── validators/                     # Zod schemas — shared client + server
│   ├── utils/
│   ├── logger.ts
│   └── constants/
│
├── seo/
│   ├── metadata.ts
│   ├── schema.ts                       # JSON-LD structured data
│   └── opengraph.ts
│
├── emails/                             # reserved, empty for v1
│   └── templates/
│
├── config/
│   ├── brand.ts                        # name, tagline, logo paths, contact, WhatsApp,
│   │                                    # email, social links, default SEO values
│   ├── navigation.ts
│   ├── social.ts
│   └── theme.ts
│
├── content/                            # static copy — see migration rule above
│   ├── home.ts
│   └── about.ts
│
├── animations/
│   ├── hero.ts
│   ├── cards.ts
│   ├── navbar.ts
│   └── scroll.ts
│
├── providers/
│   └── query-provider.tsx
│
├── types/
│   ├── database.ts                     # generated from Supabase schema
│   └── domain.ts                       # splits into domain/ once order/cart/customer arrive
│
├── supabase/
│   ├── migrations/
│   └── seed.sql
│
├── public/
│   ├── images/
│   ├── videos/
│   ├── icons/
│   ├── logos/
│   └── favicons/
│
├── styles/
├── docs/                                # long-term engineering documentation
│   ├── architecture.md                 # Phase 1 content
│   ├── folder-structure.md             # this document
│   ├── database.md                     # written in Phase 5
│   ├── deployment.md                   # written in Phase 11
│   └── journal.md                      # running log of architectural decisions
├── README.md                           # concise — setup/dev instructions only, links to docs/
├── middleware.ts                       # protects /admin at the edge
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
└── package.json
```

---

## 3. Deferred items and where they land

- **Product media** (multiple images, video, future 360°) → Phase 5, as a normalized `product_media` table (`type`, `position`, `alt_text`, `product_id` FK). Corresponding Supabase Storage bucket structure designed at the same time.
- **Image optimization strategy** (max upload size, formats, dimensions per use case, compression, naming, storage organization) → split across Phase 4 (bucket structure/conventions) and Phase 10 (upload UI that enforces those conventions). Not solved by a folder name.
- **`domain/` folder** → not needed yet; `types/domain.ts` covers the current entity count.

---

## Approval needed before Phase 4

This document is now final for Phase 2. Proceeding to Phase 3: Project Initialization as approved.
