# Nidhas — Phase 1: Architecture

## 1. Stack recommendation (one change proposed)

**Proposed change: Next.js (App Router) instead of plain Vite, for the public storefront. Keep the rest of the stack as specified.**

| Layer | Original brief | Recommendation | Change? |
|---|---|---|---|
| Frontend framework | React + Vite | **Next.js 14+ (App Router)** | Changed |
| Language | TypeScript | TypeScript | Same |
| Styling | Tailwind CSS | Tailwind CSS | Same |
| Animation | Framer Motion + GSAP | Framer Motion + GSAP | Same |
| Component primitives | shadcn/ui | shadcn/ui (admin-heavy use; storefront heavily re-skinned) | Same, with caveat |
| Backend | Supabase | Supabase | Same |
| Database | PostgreSQL | PostgreSQL | Same |
| Auth | Supabase Auth | Supabase Auth | Same |
| Storage | Supabase Storage | Supabase Storage | Same |
| Hosting | Vercel | Vercel | Same |

**Why the swap, concretely:**

- **SEO.** Product/collection pages need to be crawlable without executing JS. Next.js gives you Static Site Generation (SSG) for pages that rarely change (homepage, About, collection listings) and Incremental Static Regeneration (ISR) for product pages that update when the admin edits them — regenerate in the background, no full redeploy needed.
- **Social/WhatsApp previews.** Each product page needs its own Open Graph tags (`og:image`, `og:title`, `og:description`) generated server-side from that product's actual photo and name. This is the mechanism that makes a shared WhatsApp link show the product card instead of a generic favicon. Vite CSR cannot do this without a separate prerendering hack; Next.js does it natively via `generateMetadata`.
- **Same language, same component model, same hosting.** This isn't a stack overhaul — it's swapping the build tool/router layer under the same React + TypeScript + Tailwind code you'd write anyway. Vercel is built by the Next.js team, so deployment is if anything *simpler* than generic Vite-on-Vercel.
- **Admin panel doesn't need any of this.** It's authenticated, not indexed, never shared as a link. It can be plain client-rendered React routes inside the same Next.js app (`/admin/*`), so you don't end up maintaining two separate frontend projects.

**What you lose by switching:** Vite's raw dev-server speed advantage, and a slightly simpler mental model (no server/client component split to reason about). Given this is a real client project where SEO and link-sharing are core to the business model, that trade is worth it.

**If you'd rather keep pure Vite:** it's workable if you pair it with a prerendering step (e.g., a static-export plugin) for public routes only, and accept that dynamic per-product OG tags require extra tooling. I'd only recommend this path if you have a strong reason to avoid Next.js — happy to go that route instead if you prefer, but flagging it as the weaker option for this specific brief.

---

## 2. Why each technology (assuming the Next.js swap is accepted)

- **Next.js (App Router):** SSR/SSG/ISR for SEO and social previews; file-based routing scales cleanly as more route groups (`/admin`, future `/account`, `/checkout`) get added; native Vercel integration; React Server Components reduce client bundle size, which matters on the mobile networks most of your actual customers will be browsing on.
- **TypeScript:** Non-negotiable for a project that will grow into inventory, orders, and payments. Types generated directly from the Supabase schema (`supabase gen types typescript`) mean a schema change surfaces as a compile error in the frontend instead of a silent runtime bug — critical once money is involved.
- **Tailwind CSS:** Fast, consistent spacing/typography scale (important for the "large spacing, elegant hierarchy" brief), small shipped CSS via purging, no fighting a separate CSS architecture.
- **Framer Motion:** Component-level transitions (page transitions, card hovers, modal reveals) — idiomatic in React, declarative.
- **GSAP + ScrollTrigger:** For the more complex scroll-driven sequences (image reveals, floating movement, pinned sections) that Framer Motion handles less gracefully. Used selectively, not as the default.
- **shadcn/ui:** Copy-in, unstyled-by-default components — good accessibility and keyboard behavior out of the box. **Caveat:** use it primarily for the admin dashboard (tables, forms, dialogs) where "looks like shadcn" is fine. For the public storefront, treat it as a structural/accessibility base only — every visual surface needs custom styling, or it will read as the generic template your own brief explicitly rejects.
- **Supabase (Postgres + Auth + Storage):** One backend covers relational data, authentication, RLS-based authorization, and file storage — no separate services to wire together for a v1 of this size. Row-Level Security is what lets "admin can edit, public can only read" be enforced at the database layer, not just hidden in the UI (more on this in Risks).
- **PostgreSQL specifically:** Relational integrity is not optional once you add orders/inventory later — stock decrementing on purchase, order line items referencing products, coupon redemption limits — these all need real foreign keys and transactions. A document/NoSQL store would make the ecommerce phase harder, not easier.
- **Vercel:** Zero-config CI/CD, preview deployments per branch/PR (useful for showing your uncle changes before they go live), edge network for fast image/page delivery across India.

---

## 3. High-level folder structure (structural only — no implementation yet)

```
nidhas/
├── app/
│   ├── (storefront)/          # public routes — SSG/ISR
│   │   ├── page.tsx           # homepage
│   │   ├── collections/
│   │   ├── products/[slug]/
│   │   └── contact/
│   ├── admin/                 # authenticated routes — CSR, behind middleware
│   │   ├── products/
│   │   ├── enquiries/
│   │   └── homepage-content/
│   └── api/                   # route handlers (kept minimal; Supabase does most work)
├── components/
│   ├── ui/                    # shadcn primitives
│   ├── storefront/            # brand-specific, heavily custom-styled
│   └── admin/                 # dashboard-specific
├── lib/
│   ├── supabase/              # client instances (browser + server)
│   └── utils/
├── types/
│   ├── database.ts            # generated from Supabase schema
│   └── domain.ts               # hand-written domain types
├── supabase/
│   ├── migrations/
│   └── seed.sql
├── styles/
└── public/
```

Nothing in this structure has to change when ecommerce features are added — `orders/`, `checkout/`, `account/` slot into `app/(storefront)/` the same way, and new tables slot into `supabase/migrations/` the same way.

---

## 4. How the pieces interact

```
                         ┌─────────────────────┐
                         │      Customer        │
                         │   (browser/mobile)   │
                         └──────────┬───────────┘
                                    │  HTTPS
                                    ▼
                         ┌─────────────────────┐
                         │  Vercel Edge Network │
                         │  (CDN + hosting)     │
                         └──────────┬───────────┘
                                    │
                    ┌───────────────┴────────────────┐
                    ▼                                  ▼
        ┌───────────────────────┐         ┌───────────────────────┐
        │   Next.js Storefront   │         │   Next.js Admin App    │
        │  SSG/ISR public pages  │         │  CSR, auth-gated       │
        │  generateMetadata →    │         │  /admin/*              │
        │  per-product OG tags   │         │                        │
        └───────────┬────────────┘         └───────────┬────────────┘
                    │                                    │
                    │        Supabase client SDK         │
                    └───────────────┬────────────────────┘
                                    ▼
                    ┌─────────────────────────────┐
                    │           Supabase            │
                    │  ┌─────────┐  ┌────────────┐ │
                    │  │ Postgres │  │  Supabase  │ │
                    │  │  (RLS)   │  │    Auth    │ │
                    │  └─────────┘  └────────────┘ │
                    │  ┌────────────────────────┐  │
                    │  │   Supabase Storage      │  │
                    │  │  (product images/video) │  │
                    │  └────────────────────────┘  │
                    └─────────────────────────────┘

WhatsApp Enquiry → wa.me deep link (no backend involved, just a formatted URL)
```

Key point: public storefront pages read from Postgres via Supabase's client SDK at build/revalidation time (ISR) — not on every request from every visitor. Admin pages read/write live, gated by Supabase Auth + RLS policies that check the user's role, not just the UI hiding buttons.

---

## 5. Risks and future scalability concerns

1. **RLS discipline is the real security boundary, not the admin UI.** A common beginner mistake is hiding admin buttons in the frontend and assuming that's "access control." It isn't — anyone can call the Supabase API directly. Every table needs explicit RLS policies (public read on `products`/`collections`, write restricted to authenticated admin role) from Phase 5 onward. This gets covered in detail in the Database and Auth phases, but it's a foundational risk worth naming now.

2. **Schema headroom for ecommerce, designed now, built later.** To avoid a rewrite when payments/cart/orders arrive, the Phase 5 schema should reserve the shape for `orders`, `order_items`, `inventory`, `coupons`, `addresses` even though those tables stay empty/unused in v1. Retrofitting foreign keys onto a live product catalogue later is more disruptive than designing them now and leaving them dormant.

3. **Storage cost/CDN behavior at scale.** Supabase Storage is fine for v1 volume, but fashion catalogues are image-heavy (multiple angles per product, plus video). Worth monitoring egress costs as the catalogue grows; Next.js's built-in image optimization (`next/image`) mitigates a lot of this by serving resized/compressed variants rather than raw uploads.

4. **Vendor concentration on Supabase.** Auth, DB, and storage all sitting in one provider is a deliberate speed trade-off for v1, but it means a future migration off Supabase (unlikely, but possible) touches everything at once rather than one layer at a time. Acceptable given the project size and timeline — just naming it as a real trade-off, not a hidden one.

5. **Payment gateway integration point.** When online payment is added, it'll most likely be Razorpay (dominant for Indian SMB ecommerce) via a Supabase Edge Function handling the webhook (order confirmation, signature verification) server-side — never trusting a client-side "payment succeeded" call. Nothing to build now, just confirming the architecture has a clean slot for it (Edge Functions), which it does.

6. **shadcn default look leaking into the storefront.** Named above, repeating because it's a design risk, not just a technical one: without deliberate re-theming, shadcn's component defaults will fight the "editorial, luxury, custom-designed" brief. This is a Phase 7 (UI Design System) concern, but worth flagging at the architecture level since it affects how much custom Tailwind config/theming work to budget for.

---

## 6. Security model: Supabase client usage (added post-Phase 4)

Three distinct clients exist in this codebase. Conflating them is the single most common way a Supabase project's security model quietly breaks, so the rule is stated explicitly rather than left implicit in the code:

| Client | Key used | Where it lives | RLS enforced? | Used for |
|---|---|---|---|---|
| Browser client | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | `lib/supabase/client.ts` | Yes | Client Components, TanStack Query hooks |
| Server client | `NEXT_PUBLIC_SUPABASE_ANON_KEY` + user's session cookies | `lib/supabase/server.ts` | Yes | Server Components, normal route handlers |
| Admin client | `SUPABASE_SERVICE_ROLE_KEY` | `lib/supabase/admin.ts` | **No — bypasses RLS entirely** | Standalone scripts, future cron jobs, audited webhook handlers only |

**The principle: prefer RLS everywhere, only bypass it intentionally.** "Server-side" and "`service_role`" are not synonyms — the default server client authenticates as the actual logged-in user via their session cookies and stays fully subject to RLS, exactly like the browser client. `service_role` is reserved for a narrow, explicitly-audited set of cases: data imports, maintenance scripts, future scheduled jobs, and payment webhook reconciliation (verify the webhook signature *first*, only then touch the admin client).

**Hard rule:** `lib/supabase/admin.ts` is never imported from a Server Component, a page, or a normal route handler backing a user-facing feature. It's only called from `scripts/`, from genuinely trusted server-only jobs, or from a webhook handler that has already independently verified the request's authenticity before it ever touches the database.

```typescript
// lib/supabase/admin.ts — the ONLY place service_role gets instantiated
import { createClient } from "@supabase/supabase-js";

export function createAdminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}
```


## 7. Data access pattern — permanent rule

```
UI  →  Service Layer  →  Validator  →  Supabase
```

React components — whether in `app/(storefront)/` or `app/admin/` — never call a Supabase client directly. Every read or write goes through a `lib/services/*.service.ts` function, and every write additionally goes through the matching Zod schema in `lib/validators/` before it reaches Supabase. This is what makes the client-agnostic service layer (Section 6) actually hold in practice: if a component could reach for `createClient()` directly as a shortcut, the server/client boundary and the single-source-of-truth validation rule both quietly erode over time, one convenient exception at a time. The rule has no carve-out for "just this once."

## Status

Phases 1–5 approved. This document is updated incrementally as cross-cutting architectural decisions are made in later phases — see docs/journal.md for the full chronological record.
