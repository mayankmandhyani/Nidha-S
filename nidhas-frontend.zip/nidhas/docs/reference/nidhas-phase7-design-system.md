# Nidhas — Phase 7: Complete Design System

Note on the gold rule from the previous pass: demoted to a **candidate** motion detail, not a defining brand element. It stays available as a component (Part K) but nothing else in this system depends on it, and it isn't presented as "the" signature anymore — that gets decided at polish, once logo and photography exist together.

---

## Part A — Color tokens

| Token | Hex | Role | Contrast note |
|---|---|---|---|
| `ivory` | `#FAF6EF` | Primary background | — |
| `sand` | `#EDE3D3` | Secondary surface (cards, alt sections) | — |
| `gold` | `#B8935A` | Accent | **Fails WCAG AA for normal text on ivory.** Restricted to: large display text (24px+/18.66px bold+), borders, underlines, icons, backgrounds sitting behind dark text. Never used as small body/label text color. |
| `espresso` | `#2B2420` | Primary text, dark surfaces | Passes AAA on ivory — safe everywhere |
| `brown` | `#7A5B3E` | Secondary accent, links, labels | Passes AA on ivory for normal text — safe for body-sized use where gold isn't |
| `mist` | `#DDD3C4` | Borders, dividers | — |

This restriction on gold is worth stating explicitly rather than discovering later — it's the reason product prices, form labels, and body copy use `brown` or `espresso`, and `gold` shows up only in underlines, borders, and large headline moments.

---

## Part B — Typography scale

Fraunces (display) + Manrope (body), as established. Full scale:

| Token | Size / Line-height | Weight | Usage |
|---|---|---|---|
| `display-xl` | 4.5rem / 1.05 | 500 | Hero headline |
| `display-lg` | 3rem / 1.1 | 500 | Section headlines |
| `display-md` | 2.25rem / 1.15 | 500 | Card/subsection headlines |
| `display-sm` | 1.5rem / 1.25 | 500 | Product name, small headline |
| `body-lg` | 1.125rem / 1.6 | 400 | Intro/lead paragraphs |
| `body-base` | 1rem / 1.6 | 400 | Default body text |
| `body-sm` | 0.875rem / 1.5 | 400 | Secondary text, captions |
| `label` | 0.75rem / 1.4 | 600 | Uppercase, `tracking-label` (0.14em) — eyebrows, badges, form labels, metadata |

All display sizes scale down roughly 20–25% on mobile via Tailwind responsive prefixes (`text-3xl md:text-5xl` pattern), not a separate token set — one scale, responsive at the utility level.

---

## Part C — Spacing, containers, grid, breakpoints

**Spacing rhythm** — restricted to Tailwind's default scale, with agreed conventions so vertical rhythm stays consistent rather than ad hoc per page:

| Context | Value |
|---|---|
| Section vertical padding | `py-24` mobile → `py-40` desktop |
| Content block gap (within a section) | `space-y-8` |
| Card internal padding | `p-6` |
| Grid gap (product/collection grids) | `gap-6` mobile → `gap-8` desktop |

**Container:** `max-w-[1440px] mx-auto px-6 md:px-12 lg:px-20` — one container convention reused everywhere, not redefined per page.

**Grid:**
- Product grid: 2 columns mobile → 3 tablet → 4 desktop (`grid-cols-2 md:grid-cols-3 lg:grid-cols-4`)
- Editorial split sections (image + text): 2 columns from `md` up, asymmetric (`md:grid-cols-[3fr_2fr]`), stacked below `md`

**Breakpoints:** Tailwind defaults (`sm` 640 / `md` 768 / `lg` 1024 / `xl` 1280 / `2xl` 1536) — deliberately not customized. No part of this brief needs a nonstandard breakpoint, and matching the ecosystem default means every future dependency's responsive behavior stays predictable.

---

## Part D — Radius and shadow

**Radius:** near-square throughout (`--radius: 0.125rem`, already set). No separate large-radius token — nothing in an editorial layout should read as a "rounded card," including modals and toasts.

**Shadow — deliberately minimal.** Product, collection, and testimonial cards use **no shadow at all** — separation comes from whitespace and hairline borders (`border-mist`), consistent with the flat, print-catalogue-inspired layout. The only shadow token in the system is for genuinely floating UI:

```css
--shadow-float: 0 8px 30px -8px rgb(43 36 32 / 0.12);
```

Used exclusively on: dropdown menus, modals/dialogs, toasts. If a shadow shows up anywhere else, that's a deviation from the system, not a variant of it.

---

## Part E — Buttons

Three variants, all uppercase label + `tracking-label`, generous horizontal padding (`px-8 py-3`):

```typescript
// components/ui/button.tsx — variant additions to the shadcn base
const buttonVariants = {
  primary: "bg-espresso text-ivory hover:bg-espresso/90",
  secondary: "border border-espresso text-espresso bg-transparent hover:bg-espresso hover:text-ivory transition-colors",
  ghost: "text-espresso underline-offset-4 hover:underline bg-transparent",
};
```

- **Primary** — solid espresso fill. Reserved for the single most important action per view (Send Enquiry, Submit, Save Product).
- **Secondary** — outlined. Used for everything else that needs to look like a button (View Collection, Filter, Cancel).
- **Ghost** — text-only. Inline actions, "View all," tertiary links.

No fourth "danger/destructive" variant added speculatively — added in Phase 10 only if the admin panel actually needs a distinct delete-confirmation treatment, per the same "don't build ahead of a real need" principle already applied to auth.

---

## Part F — Inputs: two treatments, deliberately different

**Storefront (contact/enquiry forms): underline style.** Border-bottom only, no fill, no box — consistent with the editorial flatness of the rest of the public site.

```typescript
"border-0 border-b border-mist bg-transparent px-0 py-2 focus-visible:border-espresso focus-visible:ring-0 rounded-none"
```

**Admin panel: conventional boxed inputs.** Full border, subtle fill, standard shadcn shape (re-themed with these tokens, not the underline style). This is a deliberate split, not an inconsistency: the storefront's inputs are rare and few (one enquiry form), where editorial restraint is worth the small aesthetic cost to usability. The admin panel has dozens of fields across product forms, and admin usability (clear field boundaries, fast scanning) matters more there than matching the storefront's minimalism. Two treatments, each justified by what it's actually for.

---

## Part G — Cards

- **ProductCard** — defined in the previous pass (image-dominant, quiet metadata below, no shadow, no border).
- **CollectionCard** — full-bleed image, headline overlaid at the bottom third with a subtle gradient scrim (`bg-gradient-to-t from-espresso/60 to-transparent`) so ivory-on-image text stays legible without a solid color block breaking the photo.
- **TestimonialCard** — no border/shadow at all; a single hairline top rule (`border-t border-mist pt-6`), quote in `display-sm` italic Fraunces, name + location in `label` style beneath.
- **Admin data card / table row** — functional over editorial: full border, `sand` header row, standard density. Admin surfaces prioritize scannability over restraint, same reasoning as Part F.

---

## Part H — Badges

Small, quiet — text + thin border, not filled color chips (filled chips read as generic SaaS UI, which fights the editorial brief):

```typescript
"inline-flex items-center border border-mist px-3 py-1 text-xs uppercase tracking-label text-brown"
```

Used for: "New," "Festive," "Out of Stock" (products), enquiry status (admin: `new`/`contacted`/`closed`, color-differentiated only in the admin panel where functional clarity outranks restraint — `new` in `brown`, `contacted` in `mist`-bordered neutral, `closed` in `espresso/50`).

---

## Part I — Section layouts

Three reusable wrappers, every page assembled from these rather than one-off section markup:

```typescript
// components/storefront/section.tsx
export function FullBleedSection({ children, className = "" }: SectionProps) {
  return <section className={`w-full ${className}`}>{children}</section>;
}

export function ContainedSection({ children, className = "" }: SectionProps) {
  return (
    <section className={`max-w-[1440px] mx-auto px-6 md:px-12 lg:px-20 py-24 md:py-40 ${className}`}>
      {children}
    </section>
  );
}

export function SplitSection({ image, children, imageFirst = true }: SplitSectionProps) {
  return (
    <div className={`grid md:grid-cols-[3fr_2fr] gap-8 md:gap-16 items-center ${imageFirst ? "" : "md:[direction:rtl]"}`}>
      <div className={imageFirst ? "" : "[direction:ltr]"}>{image}</div>
      <div className="[direction:ltr] space-y-6">{children}</div>
    </div>
  );
}
```

`FullBleedSection` — hero, edge-to-edge imagery. `ContainedSection` — standard content width, the default for most sections. `SplitSection` — the asymmetric image/text pattern from the layout concept, reusable in either direction (image left or right) via `imageFirst`.

---

## Part J — Navigation

**Desktop:** logo left, nav links center, WhatsApp/contact icon right. Transparent background with `ivory` text over the hero video; on scroll past the hero, transitions to a solid `ivory` background with `espresso` text (a real hero-specific requirement, not generic nav behavior — the video needs light text over it, everywhere else needs normal contrast).

```typescript
const { scrollY } = useScroll();
const isScrolled = useTransform(scrollY, (v) => v > heroHeight);
```

**Mobile:** hamburger opens a full-screen overlay (not a slide-in drawer) — large centered `display-md` links, generous spacing, matching the editorial full-screen-takeover pattern seen in fashion sites rather than a generic app-style drawer.

---

## Part K — Footer

Four columns on desktop (collapsing to stacked accordion-style groups on mobile): Shop (categories), Collections, Contact (WhatsApp, phone, email, address), Newsletter signup. Hairline top border (`border-t border-mist`), generous top padding, `label`-style column headings.

**Optional, not committed:** the gold underline could appear here under the newsletter CTA as a small candidate placement — genuinely optional, revisit at polish per the refinement above.

```typescript
// components/shared/gold-underline.tsx — kept as an available component, not a system dependency
"use client";
import { motion } from "framer-motion";

export function GoldUnderline({ className = "" }: { className?: string }) {
  return (
    <motion.span
      initial={{ scaleX: 0 }}
      whileInView={{ scaleX: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, ease: [0.65, 0, 0.35, 1] }}
      className={`block h-px w-12 origin-left bg-gold ${className}`}
    />
  );
}
```

---

## Part L — Form components

Building on shadcn's `Form` primitives, re-themed:

- **Label:** `label` typography token (uppercase, small, wide-tracked) — not shadcn's default sentence-case label.
- **Error message:** `text-sm text-brown` — a warm, in-palette tone, not a harsh alert-red that would clash with the palette — paired with plain, specific language, never vague.
- **Helper text:** `text-sm text-espresso/60`, below the input, only when genuinely needed, not decorative filler.

---

## Part M — Modal / Dialog

shadcn `Dialog`, re-themed: `ivory` background, `--shadow-float` (the one legitimate shadow use case), thin `mist` border, generous padding (`p-8`). Close control is a minimal `×` glyph, not a filled circular icon button — consistent with the flat component language everywhere else.

---

## Part N — Toast

Adding **sonner** (the standard modern pairing with shadcn — actively maintained, styling fully overridable via CSS variables rather than fighting a more opinionated library):

```bash
npm install sonner
```

Styled minimal: `ivory` background, `espresso` text, thin `mist` border, `--shadow-float`, no colored icons — status is communicated by the message copy itself ("Product saved," "Enquiry sent"), not by a red/green/yellow color system that would break the palette discipline. Short duration (3s), bottom-right on desktop, bottom-center on mobile.

---

## Part O — Loading skeletons

Shimmer built from palette tones, not generic gray:

```typescript
"animate-pulse bg-sand"
```

Shapes mirror the real content — a `ProductCardSkeleton` is an `aspect-[3/4] bg-sand` block plus two short `bg-sand` lines, matching `ProductCard`'s exact proportions so layout doesn't shift when real content replaces the skeleton. Under `prefers-reduced-motion`, `animate-pulse` is replaced with a static `bg-sand` block rather than removing the loading indicator entirely.

---

## Part P — Empty states

One consistent pattern, reused everywhere: centered, generous padding, `display-sm` heading, one line of `body-sm` supporting text, optional secondary-variant button.

```typescript
<div className="flex flex-col items-center text-center py-24 space-y-4">
  <h3 className="font-display text-2xl">No products match your filters</h3>
  <p className="text-body-sm text-espresso/60">Try adjusting your filters or browse the full collection.</p>
  <Button variant="secondary">Clear filters</Button>
</div>
```

Used for: empty filter results, admin "no enquiries yet," admin "no testimonials yet." Copy stays plain and specific — an invitation to act, not a generic "Nothing here!" placeholder.

---

## Part Q — Error states

Distinct from empty states in tone (something went wrong vs. nothing exists), same visual structure:

```typescript
<div className="flex flex-col items-center text-center py-24 space-y-4">
  <h3 className="font-display text-2xl">Something went wrong loading this page</h3>
  <p className="text-body-sm text-espresso/60">Please try again, or contact us on WhatsApp if the problem continues.</p>
  <Button variant="primary">Try again</Button>
</div>
```

A dedicated `app/not-found.tsx` (404) follows the same structure with copy specific to a missing page/product, plus links back to the homepage and collections.

---

## Part R — Motion guidelines

One named easing curve, used everywhere rather than ad hoc per component:

```css
--ease-editorial: cubic-bezier(0.65, 0, 0.35, 1);
```

| Duration | Value | Used for |
|---|---|---|
| Fast | 150–200ms | Hover states, button interactions, focus transitions |
| Medium | 400–600ms | Scroll reveals, section entrances, image hover-scale |
| Slow | 600–900ms | Hero-level moments, page-level transitions |

**Animate transform/opacity, not layout properties** — never `width`/`height`/`top`/`left` directly, always `transform`/`opacity`, for compositor-only animation that doesn't trigger layout recalculation.

**`prefers-reduced-motion`, as a shared utility rather than per-component checks:**

```typescript
// lib/hooks/use-reduced-motion.ts
"use client";
import { useEffect, useState } from "react";

export function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const handler = () => setReduced(mq.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);
  return reduced;
}
```

Every scroll-reveal and hover-motion component checks this once, via the shared hook, rather than each component reinventing a `prefers-reduced-motion` media query independently.

---

## Part S — Accessibility rules

- **Focus indicator:** visible on every interactive element, `2px solid` `espresso` (not browser default blue, but not removed either), with sufficient offset to stay visible against both `ivory` and `sand` backgrounds.
- **Contrast:** `espresso` and `brown` are safe for text at any size; `gold` is restricted per Part A — the single most likely accessibility mistake in a gold-accented palette, worth the explicit rule.
- **Landmarks:** every page has exactly one `<main>`, nav in `<nav>`, footer in `<footer>` — screen reader users navigate by landmark, not visual position.
- **Heading hierarchy:** one `<h1>` per page, no skipped levels — a `display-lg`-styled element can still semantically be an `<h2>`; visual size and heading level are independent.
- **Alt text:** every image renders `product_media.alt_text` (Phase 5 schema) — not the filename, not a generic "product image." The admin product form (Phase 10) makes this field required at the UI level even though it's nullable in the schema — nullable for data-model flexibility, required in the actual form for content-quality discipline.
- **Keyboard navigation:** the mobile menu overlay and modals trap focus while open and return focus to the triggering element on close — both custom-enough surfaces (not plain shadcn defaults) to need this stated explicitly rather than assumed.

---

## `docs/journal.md` addition

```markdown
## Phase 7 — Design System (completed)
- Gold underline demoted from "signature element" to optional candidate — revisit at
  polish once logo/photography exist together, per explicit client direction.
- Full design language established: color, type, spacing, containers, grid,
  breakpoints, radius/shadow, buttons, inputs (two deliberate treatments — underline
  for storefront, boxed for admin, usability vs. restraint justified per surface),
  cards, badges, section layouts, nav, footer, forms, modal, toast (sonner), loading
  skeletons, empty/error states, motion guidelines, accessibility rules.
- Accessibility catch worth recording: gold fails WCAG AA for normal text on ivory —
  restricted to large text/borders/decoration; brown and espresso carry all
  body-sized text and label color.
- All later pages (Phase 9 storefront, Phase 10 admin) assembled from this component
  library, not designed independently per page.
```

---

## Approval needed before Phase 8

This is the complete design system. Confirm before Phase 8 (mock data layer).
