# Nidhas — Phase 4: Supabase Setup (Zero to Production)

## Scope note before starting

This phase covers: project creation, region choice, credential retrieval, environment variables, **dashboard-side** authentication configuration (creating the admin account, disabling public signup, session settings), storage bucket creation with policies, and verifying the connection from Next.js.

This phase does **not** cover: database tables (Phase 5), the actual login page UI (Phase 6), or the admin upload interface (Phase 10). Where this phase creates something those later phases will build on, that handoff is noted explicitly.

---

## Step 1 — Create a Supabase account

If you don't already have one: go to **supabase.com** → **Start your project** → sign up (GitHub sign-in is the fastest path and links your GitHub identity, which is convenient later if you ever use Supabase's GitHub integration features — not required, just a minor convenience).

**Verify:** you land on the Supabase dashboard at `supabase.com/dashboard`, showing an empty organization or a prompt to create one.

---

## Step 2 — Create the organization (if you don't have one)

Click **New organization** → name it something like `Nidhas` or your own name if you'll host multiple client projects under one org later → choose the **Free** plan for now.

**Why:** an organization is the billing/ownership boundary above individual projects. For a single client project this matters less now, but if you take on more client work later, keeping each client's project under a clearly-named org (or at least clearly named projects) avoids confusion about whose infrastructure you're looking at.

---

## Step 3 — Create the Supabase project

From the dashboard: **New Project** button (top right, or center of an empty org).

Fill in:

- **Name:** `nidhas` (lowercase, matches your repo name — consistency helps when you're context-switching between the Supabase dashboard, GitHub, and Vercel later)
- **Database Password:** click **Generate a password**, then **copy it immediately and store it in a password manager**. This is the direct Postgres connection password — separate from any user login password, and separate from your API keys. You will need it if you ever connect a database GUI tool (like TablePlus or pgAdmin) directly, or run migrations from the CLI. Losing it means resetting it from the dashboard, which is fine but avoidable.
- **Region:** **South Asia (Mumbai)** — this is the closest available Supabase region to your actual customer base. **This choice is permanent for the life of the project** — Supabase does not support changing a project's region after creation; moving later means creating a new project and migrating everything (schema, data, storage, auth users) by hand. Get it right now.
- **Pricing Plan:** **Free** tier. It comfortably covers development and initial launch for a catalogue site with no transactions — 500MB database, 1GB storage, 50,000 monthly active users on Auth. You'll get a clear signal (dashboard usage warnings) well before you need to upgrade to Pro.

Click **Create new project**.

**Expected output:** a provisioning screen, typically 1–2 minutes. Do not navigate away.

**Verify:** the dashboard loads showing your project's home page, with a green "Project is healthy" style status indicator (exact wording varies by dashboard version) and a left sidebar showing Table Editor, Authentication, Storage, SQL Editor, etc.

---

## Step 4 — Retrieve API credentials

Left sidebar → **Project Settings** (gear icon, bottom) → **API**.

You'll see three values that matter right now:

| Value | What it is | Where it's used |
|---|---|---|
| **Project URL** | `https://<project-ref>.supabase.co` | Both browser and server clients |
| **anon / public key** | A key that respects Row-Level Security | Browser client — safe to expose publicly |
| **service_role key** | A key that **bypasses RLS entirely** | Server-only — must never reach the browser |

**This is the single most important security distinction in this phase.** The `anon` key is designed to be public — it's shipped in your browser bundle and RLS policies (Phase 5 onward) are what actually restrict what it can do. The `service_role` key has no restrictions at all — anyone holding it has full read/write access to every table, bypassing every policy you write. If it ever ends up in client-side code, in a public GitHub repo, or in a `NEXT_PUBLIC_`-prefixed environment variable, that's a full data breach, not a bug. It only ever gets used in server-side code (API routes, server actions) that you control.

**Verify:** all three values are visible and copyable from this page.

---

## Step 5 — Populate `.env.local`

In your project root (created in Phase 3, gitignored), fill in:

```
NEXT_PUBLIC_SUPABASE_URL=https://<project-ref>.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=<your anon key>
SUPABASE_SERVICE_ROLE_KEY=<your service_role key>
```

**Why the `NEXT_PUBLIC_` prefix matters:** Next.js only exposes environment variables to the browser if they're prefixed `NEXT_PUBLIC_`. That's exactly why the URL and anon key have the prefix (the browser client needs them) and the service_role key deliberately does not (it must stay server-only, and Next.js will refuse to expose it to the browser bundle as long as the prefix is absent — this is a real technical safeguard, not just a naming convention).

**Verify:** `.env.local` exists at the project root, is listed in `.gitignore`, and `git status` shows it as untracked/ignored — not staged.

---

## Step 6 — Update `next.config.ts` with the real Storage domain

Now that the project exists, replace the Phase 3 placeholder:

```typescript
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "<project-ref>.supabase.co",
        pathname: "/storage/v1/object/public/**",
      },
    ],
  },
};

export default nextConfig;
```

**Why:** Next.js's `<Image>` component requires every external image domain to be explicitly allowlisted. Without this, product images served from Supabase Storage (Phase 10 onward) would fail to render with an "Invalid src prop" error.

---

## Step 7 — Authentication configuration (dashboard side)

Left sidebar → **Authentication** → **Providers**.

- **Email** provider: should be enabled by default. This is the only provider Nidhas needs — no Google/Facebook OAuth required, since there's exactly one type of account in v1: the admin.
- Click into the **Email** provider settings. **Confirm email:** for v1, turn this **off**. Here's why this is a deliberate choice, not a shortcut: Nidhas has no public signup flow. The only account that will ever exist is the one admin account, which you're about to create manually from the dashboard, not through a public form. Email confirmation exists to verify that a self-registered user owns the email they signed up with — irrelevant when you're the one creating the account and you already know it's correct. If a public customer-facing account system is added later (the future ecommerce phase), this setting gets revisited then, scoped to that new signup flow specifically.

Left sidebar → **Authentication** → **URL Configuration**:

- **Site URL:** `http://localhost:3000` for now. This becomes your production Vercel domain in Phase 11 — note it as a to-do, don't forget to update it at deployment time or auth redirects will point to localhost in production.
- **Redirect URLs:** add `http://localhost:3000/**` for local development.

---

## Step 8 — Create the admin user

Left sidebar → **Authentication** → **Users** → **Add user** → **Create new user**.

Enter the admin email (yours, or your uncle's — whoever will actually log in to manage products) and a strong password. Check **Auto Confirm User** (skips the email confirmation step you just disabled anyway, so this box should be checked for the same reason).

Click **Create user**.

**Why manual creation, not a signup form:** there is intentionally no public `/admin/signup` route anywhere in this architecture. The only way to create an admin account is through this dashboard, by someone with Supabase project access. That's a real security boundary, not an oversight — a public signup page for the admin panel would be a standing invitation for anyone to attempt to create an account with admin-level intent.

**Verify:** the new user appears in the Users table with status "Confirmed."

---

## Step 9 — Storage bucket naming and structure

Buckets, one per media category, kebab-case:

| Bucket | Purpose | Public read? |
|---|---|---|
| `product-media` | Product images, video, future 360° — backs the `product_media` table from Phase 5 | Yes |
| `hero-banner` | Homepage hero images/video | Yes |
| `testimonials` | Customer photos, if used | Yes |
| `site-assets` | About/brand story imagery, misc admin-managed visuals | Yes |

All four are **publicly readable** (anyone can view a product photo — that's the point of a catalogue site) but **writes are restricted to the authenticated admin** via policies in the next step. "Public bucket" in Supabase only controls anonymous read access — it says nothing about who can upload, update, or delete. That's a separate, explicit policy layer, and skipping it is a common way public buckets get abused.

---

## Step 10 — Create the buckets

Left sidebar → **Storage** → **New bucket**, repeated for each:

For each bucket:
- **Name:** exactly as listed above (`product-media`, `hero-banner`, `testimonials`, `site-assets`)
- **Public bucket:** toggle **ON**
- **File size limit:** `10 MB` for `product-media`, `hero-banner`, `site-assets` (covers high-quality compressed images and short video clips comfortably); `5 MB` for `testimonials` (photos only, no video expected)
- **Allowed MIME types:** restrict at the bucket level —
  - `product-media`: `image/jpeg, image/png, image/webp, video/mp4`
  - `hero-banner`: `image/jpeg, image/png, image/webp, video/mp4`
  - `testimonials`: `image/jpeg, image/png, image/webp`
  - `site-assets`: `image/jpeg, image/png, image/webp`

**Why restrict MIME types at the bucket level:** this is a first line of defense against someone uploading an unexpected file type (a script disguised with an image extension, for instance) — Supabase rejects it before it ever gets stored, rather than relying on your application code to catch it after the fact.

**Verify:** all four buckets appear in the Storage section, each showing "Public" and the configured size/type restrictions.

---

## Step 11 — Storage RLS policies

Left sidebar → **SQL Editor** → **New query**. Run the following (repeated per bucket — shown here for `product-media`; duplicate the pattern for `hero-banner`, `testimonials`, `site-assets` by changing the bucket name):

```sql
-- Public read access — anyone can view product media
create policy "Public read access for product-media"
on storage.objects for select
using ( bucket_id = 'product-media' );

-- Authenticated write access — only a logged-in user can upload
create policy "Authenticated upload for product-media"
on storage.objects for insert
to authenticated
with check ( bucket_id = 'product-media' );

-- Authenticated update access
create policy "Authenticated update for product-media"
on storage.objects for update
to authenticated
using ( bucket_id = 'product-media' );

-- Authenticated delete access
create policy "Authenticated delete for product-media"
on storage.objects for delete
to authenticated
using ( bucket_id = 'product-media' );
```

**Why these specific policies:** `storage.objects` is itself a Postgres table with RLS — every file operation is a row operation subject to these policies, the same mechanism you'll use for actual product data in Phase 5. The `select` policy has no `to authenticated` restriction because public visitors need to view product images without being logged in. The `insert`/`update`/`delete` policies restrict to `to authenticated`, meaning only a logged-in session can write.

**A real limitation worth naming now, not hiding:** "authenticated" currently means "the one admin account," because that's the only account type that exists. The moment a future customer-account system is added, any logged-in customer would also satisfy `to authenticated` — which is wrong; a customer should never be able to upload to `product-media`. When that phase arrives, these policies need to tighten to an actual role check (e.g., `exists (select 1 from profiles where id = auth.uid() and role = 'admin')`), not just "any logged-in user." Flagging this now so it doesn't get assumed as a solved, permanent security model — it's correct for the current single-admin reality, not forever.

**Verify:** run `select * from pg_policies where tablename = 'objects';` in the SQL Editor — you should see 16 rows (4 policies × 4 buckets).

---

## Step 12 — Security considerations summary

- `service_role` key: server-only, never in client code, never `NEXT_PUBLIC_`-prefixed, never committed.
- Admin account: created manually via dashboard, no public signup route exists anywhere in the app.
- Storage: public read, authenticated-only write, restricted MIME types and file sizes at the bucket level.
- `authenticated = admin` is a v1 simplification, explicitly flagged for revisit once customer accounts exist.
- Database RLS (on actual tables, not just storage) starts in Phase 5 — every table gets policies before it holds real data, not after.

---

## Step 13 — Write the Supabase client files

**`lib/supabase/client.ts`** (browser client):

```typescript
import { createBrowserClient } from "@supabase/ssr";

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
```

**`lib/supabase/server.ts`** (server client — Server Components, route handlers):

```typescript
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // Called from a Server Component — safe to ignore since
            // middleware (below) handles session refresh.
          }
        },
      },
    }
  );
}
```

**`middleware.ts`** (root level — protects `/admin`, refreshes sessions at the edge):

```typescript
import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          supabaseResponse = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const isAdminRoute = request.nextUrl.pathname.startsWith("/admin");
  const isLoginRoute = request.nextUrl.pathname === "/admin/login";

  if (isAdminRoute && !isLoginRoute && !user) {
    const url = request.nextUrl.clone();
    url.pathname = "/admin/login";
    return NextResponse.redirect(url);
  }

  return supabaseResponse;
}

export const config = {
  matcher: ["/admin/:path*"],
};
```

Note: this protects the *route*, at the edge, before any page code runs. It is not a substitute for RLS — a determined actor could still call the Supabase API directly, bypassing your Next.js app entirely. RLS (Phase 5 onward) is the actual authorization boundary; this middleware is the UX layer that keeps a logged-out visitor from ever seeing the admin UI in the first place.

---

## Step 14 — Local connection test

Rather than building throwaway UI in real app routes, verify the connection with a standalone script.

Install a TypeScript runner if you don't have one:

```bash
npm install -D tsx
```

**`scripts/test-connection.ts`:**

```typescript
import { createClient } from "@supabase/supabase-js";
import * as dotenv from "dotenv";

dotenv.config({ path: ".env.local" });

async function testConnection() {
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  const { data: buckets, error } = await supabase.storage.listBuckets();

  if (error) {
    console.error("❌ Connection failed:", error.message);
    process.exit(1);
  }

  console.log("✅ Connected to Supabase project.");
  console.log(
    "Buckets found:",
    buckets.map((b) => b.name)
  );
}

testConnection();
```

Run:

```bash
npx tsx scripts/test-connection.ts
```

**Expected output:**

```
✅ Connected to Supabase project.
Buckets found: [ 'product-media', 'hero-banner', 'testimonials', 'site-assets' ]
```

If this fails: check `.env.local` values are correct (no trailing spaces, no quotes around the values), and that the project is fully provisioned (Step 3).

Delete or keep `scripts/test-connection.ts` as a reusable connectivity check — it's not part of the app runtime, just a diagnostic tool.

---

## Verification checklist for this phase

- [ ] Project created in South Asia (Mumbai), database password stored securely
- [ ] `.env.local` populated, confirmed gitignored
- [ ] `next.config.ts` updated with real Storage domain
- [ ] Email confirmation disabled, admin user created and confirmed in dashboard
- [ ] Site URL / Redirect URLs set for local dev
- [ ] All 4 buckets created with correct public/private, size, and MIME restrictions
- [ ] 16 storage policies confirmed via `pg_policies` query
- [ ] `lib/supabase/client.ts`, `lib/supabase/server.ts`, `middleware.ts` in place
- [ ] `scripts/test-connection.ts` runs successfully

---

## Approval needed before Phase 5

Phase 5 is Database Design — the actual schema (`products`, `categories`, `collections`, `product_media`, `testimonials`, `enquiries`), relationships, and table-level RLS policies. Confirm Phase 4 before we move there.
