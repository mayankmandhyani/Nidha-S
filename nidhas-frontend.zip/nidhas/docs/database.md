# Nidhas — docs/database.md (Phase 5, finalized)

## Part A — Reasoning

### A0. Design principles applied across every table

**UUID primary keys (`gen_random_uuid()`), not serial integers.** Prevents catalogue enumeration and avoids collisions across environments.

**`created_at` / `updated_at` on every table**, `updated_at` maintained by trigger, not application code.

**`TEXT` + `CHECK` instead of native `ENUM`**, for flexibility — adding a new allowed value later is a one-line `ALTER TABLE`, not a Postgres enum-migration.

**`is_admin()` helper**, reused across every policy rather than repeating the admin-check subquery:

```sql
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;
```

**Default RLS philosophy for every table in this project, present and future:**

```
Public SELECT (scoped to whatever "visible" means for that table)
    ↓
Admin ALL (via is_admin())
    ↓
No implicit access — anything not explicitly granted is denied by default
```

Any table that needs to deviate from this (like `enquiries`, which is public-insert-only with no public select, or `profiles`, which has no public access at all) does so as a documented, deliberate exception — not as an accidental gap. When a new table is added in a future phase, this is the default to start from, and any deviation gets the same explicit reasoning treatment the exceptions below already get.

---

### A1. `profiles`

Unchanged from the original design: no default `role`, so every insert must state it explicitly — closes off the failure mode where a future public signup silently creates admin-privileged accounts.

---

### A2. `categories` vs. `collections`

Unchanged reasoning: one-to-many taxonomy (garment type) vs. many-to-many curated groupings. "New Arrivals" stays a computed query, not a stored row.

**Slug case-insensitivity.** Using `citext` rather than `unique(lower(slug))` for `categories.slug`, `collections.slug`, and `products.slug`. Both solve the immediate problem, but `unique(lower(slug))` only works correctly if every future query that compares against `slug` remembers to wrap both sides in `lower()` — miss that once, in one query, in one component built eight months from now, and you get a case-sensitive lookup silently coexisting with case-insensitive ones. `citext` makes case-insensitive comparison the column's actual behavior, so `WHERE slug = $1` is simply correct everywhere, by default, with no discipline required from whoever writes the next query. The extra extension dependency is a trivial cost against that. `sku` on `product_variants` stays plain `text` — it's admin-entered, not a public URL, and case-sensitivity there isn't a real user-facing problem.

---

### A3. `products`, `product_variants`, `product_media`

Unchanged core reasoning (variants and media as separate, future-ready tables). Three additions:

- **`is_featured`, `seo_title`, `seo_description`** on `products` — cheap now, and exactly the kind of column that's annoying to backfill later once real product data and real page traffic exist. `seo_title`/`seo_description` are nullable and meant to override the generated defaults in `generateMetadata` (Phase 9) on a per-product basis when the auto-generated version isn't ideal for a specific listing.
- **`product_variants` gets a non-empty constraint** — `CHECK (size IS NOT NULL OR color IS NOT NULL)` — a variant row that specifies neither dimension isn't a variant, it's an empty row that would silently corrupt any future "select available sizes for this product" query.
- **`product_media` gets `caption`, separate from `alt_text`**, and a hard guarantee of at most one primary image per product via a partial unique index rather than just a boolean convention the application has to remember to enforce.

**Product pricing — resolved, not deferred.** `price` stays nullable. The Phase 9 product page displays the price whenever the field is set, and falls back to the WhatsApp enquiry CTA whenever it's null. This is a per-product admin choice, not a site-wide toggle — some items can show price, others can withhold it, without a schema change either way.

---

## Part B — SQL

### B0. Extensions and shared trigger function

```sql
create extension if not exists pgcrypto;
create extension if not exists citext;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
```

### B1. `profiles`

```sql
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null check (role in ('admin', 'customer')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create trigger set_profiles_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;
```

Backfill the Phase 4 admin account:

```sql
select id, email from auth.users where email = '<your admin email>';

insert into public.profiles (id, full_name, role)
values ('<paste-the-uuid-here>', 'Admin', 'admin');
```

### B2. `categories`

```sql
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug citext not null unique,
  description text,
  display_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_categories_slug on public.categories(slug);
create index idx_categories_active on public.categories(is_active) where is_active = true;

create trigger set_categories_updated_at
  before update on public.categories
  for each row execute function public.set_updated_at();
```

### B3. `collections`

```sql
create table public.collections (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug citext not null unique,
  description text,
  cover_image_path text,
  display_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_collections_slug on public.collections(slug);
create index idx_collections_active on public.collections(is_active) where is_active = true;

create trigger set_collections_updated_at
  before update on public.collections
  for each row execute function public.set_updated_at();
```

### B4. `products`

```sql
create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.categories(id) on delete restrict,
  name text not null,
  slug citext not null unique,
  description text,
  fabric_details text,
  price numeric(10, 2),
  is_active boolean not null default true,
  is_featured boolean not null default false,
  seo_title text,
  seo_description text,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_products_slug on public.products(slug);
create index idx_products_category on public.products(category_id);
create index idx_products_active on public.products(is_active) where deleted_at is null;
create index idx_products_featured on public.products(is_featured) where is_featured = true;
create index idx_products_created_at on public.products(created_at desc);

create trigger set_products_updated_at
  before update on public.products
  for each row execute function public.set_updated_at();
```

### B5. `product_collections` (join table)

```sql
create table public.product_collections (
  product_id uuid not null references public.products(id) on delete cascade,
  collection_id uuid not null references public.collections(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (product_id, collection_id)
);

create index idx_product_collections_collection on public.product_collections(collection_id);
```

### B6. `product_variants`

```sql
create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  size text,
  color text,
  sku text unique,
  stock_quantity integer check (stock_quantity >= 0),
  price_override numeric(10, 2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint variant_not_empty check (size is not null or color is not null)
);

create index idx_product_variants_product on public.product_variants(product_id);

create trigger set_product_variants_updated_at
  before update on public.product_variants
  for each row execute function public.set_updated_at();
```

### B7. `product_media`

```sql
create table public.product_media (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  media_type text not null check (media_type in ('image', 'video', 'three_sixty')),
  storage_path text not null,
  alt_text text,
  caption text,
  display_order integer not null default 0,
  is_primary boolean not null default false,
  created_at timestamptz not null default now()
);

create index idx_product_media_product on public.product_media(product_id, display_order);

create unique index idx_product_media_one_primary
  on public.product_media (product_id)
  where (is_primary = true);
```

Note for Phase 10 (admin upload UI): the partial unique index *prevents* two primary images from coexisting, but doesn't automatically un-set the old one when a new primary is chosen — the admin product-edit flow needs to explicitly clear the previous `is_primary` before setting the new one (in the same transaction), or the second insert/update will simply fail the constraint.

### B8. `testimonials`

```sql
create table public.testimonials (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  location text,
  quote text not null,
  photo_path text,
  rating integer check (rating between 1 and 5),
  is_published boolean not null default false,
  display_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_testimonials_published on public.testimonials(is_published) where is_published = true;

create trigger set_testimonials_updated_at
  before update on public.testimonials
  for each row execute function public.set_updated_at();
```

### B9. `enquiries`

```sql
create table public.enquiries (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references public.products(id) on delete set null,
  customer_name text not null,
  phone text not null,
  email text,
  message text,
  status text not null default 'new' check (status in ('new', 'contacted', 'closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint phone_length check (length(phone) between 8 and 20)
);

create index idx_enquiries_status on public.enquiries(status);
create index idx_enquiries_created_at on public.enquiries(created_at desc);
create index idx_enquiries_product on public.enquiries(product_id);

create trigger set_enquiries_updated_at
  before update on public.enquiries
  for each row execute function public.set_updated_at();
```

The length check is deliberately loose (8–20 characters) rather than a digit-pattern regex — it tolerates spaces, dashes, and a `+91` country code prefix, which real users will type in inconsistently. Stricter format validation, if wanted later, belongs in the Zod schema (client-side UX feedback) rather than the database constraint (which is a last-resort backstop, not the primary validation layer).

### B10. `hero_banners`

```sql
create table public.hero_banners (
  id uuid primary key default gen_random_uuid(),
  headline text not null,
  subheadline text,
  cta_text text,
  cta_link text,
  open_in_new_tab boolean not null default false,
  media_path text,
  media_type text not null default 'image' check (media_type in ('image', 'video')),
  display_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_hero_banners_active on public.hero_banners(is_active) where is_active = true;

create trigger set_hero_banners_updated_at
  before update on public.hero_banners
  for each row execute function public.set_updated_at();
```

### B11. `content_blocks`

```sql
create table public.content_blocks (
  id uuid primary key default gen_random_uuid(),
  block_key text not null unique,
  title text,
  body text,
  image_path text,
  display_order integer not null default 0,
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint block_key_not_empty check (length(trim(block_key)) > 0)
);

create trigger set_content_blocks_updated_at
  before update on public.content_blocks
  for each row execute function public.set_updated_at();
```

---

## Part C — Row Level Security, table by table

### C0. Enable RLS on everything

```sql
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.collections enable row level security;
alter table public.products enable row level security;
alter table public.product_collections enable row level security;
alter table public.product_variants enable row level security;
alter table public.product_media enable row level security;
alter table public.testimonials enable row level security;
alter table public.enquiries enable row level security;
alter table public.hero_banners enable row level security;
alter table public.content_blocks enable row level security;
```

### C1. `profiles` — documented exception: no public access at all

```sql
create policy "Users can view own profile"
on public.profiles for select
using (auth.uid() = id);

create policy "Admins can view all profiles"
on public.profiles for select
using (public.is_admin());
```

No insert/update/delete policy for anyone — role changes only happen via direct database access, never through the app.

### C2. `categories` / `collections`

```sql
create policy "Public can view active categories"
on public.categories for select
using (is_active = true);

create policy "Admins have full access to categories"
on public.categories for all
using (public.is_admin())
with check (public.is_admin());

create policy "Public can view active collections"
on public.collections for select
using (is_active = true);

create policy "Admins have full access to collections"
on public.collections for all
using (public.is_admin())
with check (public.is_admin());
```

### C3. `products`

```sql
create policy "Public can view active products"
on public.products for select
using (is_active = true and deleted_at is null);

create policy "Admins have full access to products"
on public.products for all
using (public.is_admin())
with check (public.is_admin());
```

### C4. `product_collections`, `product_variants`, `product_media`

Visibility inherits from the parent product; an open `select` policy is safe since the frontend always joins through `products`.

```sql
create policy "Public can view product-collection links"
on public.product_collections for select using (true);
create policy "Admins have full access to product_collections"
on public.product_collections for all
using (public.is_admin()) with check (public.is_admin());

create policy "Public can view product variants"
on public.product_variants for select using (true);
create policy "Admins have full access to product_variants"
on public.product_variants for all
using (public.is_admin()) with check (public.is_admin());

create policy "Public can view product media"
on public.product_media for select using (true);
create policy "Admins have full access to product_media"
on public.product_media for all
using (public.is_admin()) with check (public.is_admin());
```

### C5. `testimonials`

```sql
create policy "Public can view published testimonials"
on public.testimonials for select
using (is_published = true);

create policy "Admins have full access to testimonials"
on public.testimonials for all
using (public.is_admin())
with check (public.is_admin());
```

### C6. `enquiries` — documented exception: write-only for the public

```sql
create policy "Public can submit enquiries"
on public.enquiries for insert
with check (true);

create policy "Admins have full access to enquiries"
on public.enquiries for all
using (public.is_admin())
with check (public.is_admin());
```

No public select policy — deliberate, matches the "no track-my-enquiry feature" scope.

### C7. `hero_banners` / `content_blocks`

```sql
create policy "Public can view active hero banners"
on public.hero_banners for select
using (is_active = true);

create policy "Admins have full access to hero_banners"
on public.hero_banners for all
using (public.is_admin())
with check (public.is_admin());

create policy "Public can view published content blocks"
on public.content_blocks for select
using (is_published = true);

create policy "Admins have full access to content_blocks"
on public.content_blocks for all
using (public.is_admin())
with check (public.is_admin());
```

---

## Part D — Storage policies: future role-based replacement (not applied yet)

Recorded for when customer accounts arrive and `authenticated` stops implying `admin`:

```sql
drop policy "Authenticated upload for product-media" on storage.objects;

create policy "Admin upload for product-media"
on storage.objects for insert
to authenticated
with check ( bucket_id = 'product-media' and public.is_admin() );

-- repeat the (bucket_id = '...' and public.is_admin()) pattern for
-- update/delete, and for hero-banner, testimonials, site-assets
```

---

## Verification

```sql
select tablename, rowsecurity from pg_tables where schemaname = 'public';

select tablename, count(*) from pg_policies where schemaname = 'public' group by tablename;

select p.id, p.role, u.email from public.profiles p
join auth.users u on u.id = p.id;

-- confirm citext is doing its job
select 'KURTI-RED' = 'kurti-red'::citext;  -- should return true
```

In the dashboard: **Table Editor** shows all 11 tables; **Database → Policies** shows RLS enabled with the policies above.

---

## Status

Phase 5 finalized as of this document. No open questions remain — pricing display logic (Part A3) is a resolved product decision, not deferred.
