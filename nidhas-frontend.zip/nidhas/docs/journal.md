# Nidhas — Engineering Journal

Chronological record of architectural decisions. See `docs/architecture.md`, `docs/folder-structure.md`, and `docs/database.md` for the current-state reference; this file is the history of how they got there.

## Phase 1 — Architecture
- Approved: Next.js (App Router) over plain Vite. Reason: SEO and per-product WhatsApp/social link previews require server-rendered metadata (`generateMetadata`), which a pure CSR SPA cannot provide without extra tooling.
- Stack otherwise as specified: TypeScript, Tailwind, Framer Motion, GSAP, shadcn/ui, Supabase, Vercel.

## Phase 2 — Folder Structure
- Approved: service layer in `lib/services/`, every function dependency-injected with a Supabase client (never imported internally) — preserves the server/client boundary while eliminating duplicate query logic between Server Components and TanStack Query hooks.
- Approved: TanStack Query scoped strictly to client-side interactivity (admin CRUD, optimistic updates); Server Components own all initial/SEO-relevant data fetching.
- Approved: `content/` is a migration staging ground for static copy, not a permanent parallel store — each field is deleted from `content/` the moment its corresponding Phase 10 admin screen makes it DB-backed.
- Added: `seo/`, `emails/` (reserved empty), `config/` (later split into `brand.ts` + `navigation.ts`/`social.ts`/`theme.ts`), `animations/`, `logger.ts`, `docs/`.
- Deferred to Phase 5: `product_media` table design.
- Deferred to Phase 4/10: image optimization conventions (size, format, dimensions, naming).
- Deferred: `domain/` folder — not needed until order/cart/customer entities exist; `types/domain.ts` covers v1.

## Phase 3 — Project Initialization
- Next.js app created with `--app`, `--src-dir=false`, `--import-alias "@/*"`.
- Added Prettier + `prettier-plugin-tailwindcss` (class-order consistency, not just formatting) and Husky + lint-staged (commits blocked on lint failure — accepted trade-off for a client repo, with a documented `--no-verify` escape hatch if it becomes a real velocity tax during visual-iteration phases).
- `docs/` separated from `README.md`; README stays a concise setup/overview pointer.

## Phase 4 — Supabase Setup
- Project created in South Asia (Mumbai, `ap-south-1`) — closest available region to the actual customer base; region choice is permanent per Supabase (no in-place migration).
- Email confirmation disabled; admin account created manually via dashboard — no public `/admin/signup` route exists anywhere in the architecture.
- Buckets: `product-media`, `hero-banner`, `testimonials`, `site-assets` — public read, authenticated-only write, MIME/size restricted at the bucket level.
- Storage write policies use `authenticated` as a stand-in for "admin," explicitly flagged as a v1 simplification that breaks the moment customer accounts exist.

### Post-Phase-4 refinement
- Formalized the three-Supabase-client rule in `docs/architecture.md`: `client.ts` (browser, anon key) and `server.ts` (Server Components/Route Handlers, anon key + session cookies) both stay fully RLS-enforced; `admin.ts` is the sole, isolated home for `service_role`, used only in `scripts/`, trusted jobs, and audited webhook handlers — never in a user-facing request path.

## Phase 5 — Database Design
- 11 tables: `profiles`, `categories`, `collections`, `products`, `product_collections`, `product_variants`, `product_media`, `testimonials`, `enquiries`, `hero_banners`, `content_blocks`.
- `categories` (one-to-many taxonomy) kept structurally distinct from `collections` (many-to-many curated groupings); "New Arrivals" is a computed recency query, not a stored collection row.
- `product_variants` and `product_media` built out fully now (variant-level stock field, ordered/typed media) even though v1 UI doesn't enforce stock or expose video/360° yet — avoids a schema rewrite when inventory arrives.
- Soft delete (`deleted_at`) on `products` only; `is_active`/`is_published` booleans cover the rest, where "hidden" and "archived" aren't meaningfully different intents.
- `is_admin()` helper centralizes the RLS admin check; default RLS philosophy for all tables (present and future) stated explicitly: public SELECT (scoped) → admin ALL → no implicit access, deviations documented as deliberate exceptions.
- Storage policies remain on the Phase 4 simplification; exact role-based replacement SQL recorded in `docs/database.md` Part D, not yet applied.
- Data access pattern formalized in `docs/architecture.md`: UI → Service Layer → Validator → Supabase, no exceptions — components never call a Supabase client directly.

### Finalization refinements
- `citext` chosen over `unique(lower(slug))` for `categories.slug`, `collections.slug`, `products.slug` — makes case-insensitive comparison the column's default behavior rather than something every future query has to remember to apply.
- `products`: added `is_featured`, `seo_title`, `seo_description`.
- `product_variants`: added non-empty constraint (`size IS NOT NULL OR color IS NOT NULL`).
- `product_media`: added `caption` (distinct from `alt_text`); enforced single-primary-image via partial unique index (`WHERE is_primary = true`) — note for Phase 10: the previous primary must be explicitly unset before setting a new one, the constraint only blocks the invalid end state, not the transition.
- `enquiries`: added a loose length check (8–20 chars) on `phone` — a backstop, not the primary validation layer; stricter format rules belong in the Zod schema.
- `testimonials`: added `location`.
- `hero_banners`: added `open_in_new_tab`.
- `content_blocks`: added non-empty check on `block_key`.
- Product pricing decided (not deferred): `price` stays nullable; product page shows price when set, WhatsApp CTA when null — a per-product admin choice, not a site-wide toggle.

---

## Open items carried forward
- None outstanding from Phase 5. Next: Phase 6 — Authentication (login page, in-app session handling, route protection UI on top of the Phase 4 middleware and admin account).
