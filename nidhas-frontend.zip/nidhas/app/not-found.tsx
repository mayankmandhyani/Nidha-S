import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center px-6 space-y-4">
      <h1 className="font-display text-4xl">Page not found</h1>
      <p className="text-espresso/60 max-w-sm">
        The page you&apos;re looking for doesn&apos;t exist, or may have moved.
      </p>
      <div className="flex gap-4 mt-4">
        <Button asChild variant="primary">
          <Link href="/">Go Home</Link>
        </Button>
        <Button asChild variant="secondary">
          <Link href="/collections">Browse Collections</Link>
        </Button>
      </div>
    </div>
  );
}
