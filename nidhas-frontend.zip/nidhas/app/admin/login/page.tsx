import { LoginForm } from "@/components/admin/login-form";

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-ivory">
      <div className="w-full max-w-sm space-y-6 px-6">
        <h1 className="font-display text-2xl text-center">Nidhas Admin</h1>
        <LoginForm />
      </div>
    </div>
  );
}
