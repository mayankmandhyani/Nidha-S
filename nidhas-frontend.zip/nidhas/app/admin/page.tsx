import { redirect } from "next/navigation";
import { cookies } from "next/headers";

export default async function AdminRootPage() {
  const cookieStore = await cookies();
  const hasMockSession = cookieStore.get("nidhas-mock-session");
  redirect(hasMockSession ? "/admin/dashboard" : "/admin/login");
}
