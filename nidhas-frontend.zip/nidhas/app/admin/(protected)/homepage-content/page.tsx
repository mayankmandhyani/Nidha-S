"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ContentBlockService } from "@/lib/services/content-block.service";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ErrorState } from "@/components/shared/error-state";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import type { ContentBlock } from "@/types/database";

function Skeleton() {
  return (
    <div className="space-y-2">
      {[...Array(3)].map((_, i) => (
        <div key={i} className="h-20 bg-sand animate-pulse motion-reduce:animate-none" />
      ))}
    </div>
  );
}

export default function AdminHomepageContentPage() {
  const queryClient = useQueryClient();
  const { data: blocks, isLoading, isError, refetch } = useQuery({
    queryKey: ["admin", "content-blocks"],
    queryFn: () => ContentBlockService.getAll(undefined),
  });

  const [editing, setEditing] = useState<ContentBlock | null>(null);
  const [form, setForm] = useState({ title: "", body: "" });

  const mutation = useMutation({
    mutationFn: () => ContentBlockService.update(undefined, editing!.id, form),
    onSuccess: () => {
      toast.success("Content updated.");
      queryClient.invalidateQueries({ queryKey: ["admin", "content-blocks"] });
      setEditing(null);
    },
    onError: () => toast.error("Couldn't save. Please try again."),
  });

  function openEdit(block: ContentBlock) {
    setForm({ title: block.title ?? "", body: block.body ?? "" });
    setEditing(block);
  }

  return (
    <div>
      <h1 className="font-display text-3xl mb-2">Homepage Content</h1>
      <p className="text-sm text-espresso/60 mb-8 max-w-lg">
        Brand Story, Craftsmanship, and Why Choose Nidhas — the free-form homepage sections.
        Editing here is the DB-backed replacement for the static content/ files, per the
        migration rule in docs/folder-structure.md.
      </p>

      {isLoading && <Skeleton />}
      {isError && <ErrorState onRetry={() => refetch()} />}

      {!isLoading && !isError && blocks && (
        <div className="space-y-4">
          {blocks.map((block) => (
            <div key={block.id} className="border border-mist p-5 flex items-start justify-between gap-4">
              <div>
                <p className="text-xs uppercase tracking-label text-brown mb-1">{block.block_key}</p>
                <p className="font-medium">{block.title}</p>
                <p className="text-sm text-espresso/60 mt-1 max-w-lg">{block.body}</p>
              </div>
              <Button variant="secondary" size="sm" onClick={() => openEdit(block)}>
                Edit
              </Button>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit {editing?.block_key}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-xs uppercase tracking-label font-semibold block mb-1">
                Title
              </label>
              <Input
                variant="boxed"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>
            <div>
              <label className="text-xs uppercase tracking-label font-semibold block mb-1">
                Body
              </label>
              <Textarea
                variant="boxed"
                rows={4}
                value={form.body}
                onChange={(e) => setForm({ ...form, body: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setEditing(null)}>
              Cancel
            </Button>
            <Button onClick={() => mutation.mutate()} disabled={mutation.isPending}>
              {mutation.isPending ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
