import { notFound } from "next/navigation";
import { mockStore } from "@/lib/mock-data/store";
import { ProductForm } from "@/components/admin/product-form";

interface Props {
  params: Promise<{ id: string }>;
}

export default async function EditProductPage({ params }: Props) {
  const { id } = await params;
  const product = mockStore.get().products.find((p) => p.id === id);
  if (!product) notFound();

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Edit Product</h1>
      <ProductForm existingProduct={product} />
    </div>
  );
}
