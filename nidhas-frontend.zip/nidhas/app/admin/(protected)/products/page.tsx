"use client";

import { useState } from "react";
import Link from "next/link";
import { toast } from "sonner";
import { useAdminProducts, useDeleteProduct } from "@/lib/hooks/use-products";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/shared/empty-state";
import { ErrorState } from "@/components/shared/error-state";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";

function ProductsTableSkeleton() {
  return (
    <div className="space-y-2">
      {[...Array(5)].map((_, i) => (
        <div key={i} className="h-14 bg-sand animate-pulse motion-reduce:animate-none" />
      ))}
    </div>
  );
}

export default function AdminProductsPage() {
  const { data: products, isLoading, isError, refetch } = useAdminProducts();
  const deleteProduct = useDeleteProduct();
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string } | null>(null);

  function confirmDelete() {
    if (!deleteTarget) return;
    deleteProduct.mutate(deleteTarget.id, {
      onSuccess: () => {
        toast.success(`"${deleteTarget.name}" removed.`);
        setDeleteTarget(null);
      },
      onError: () => {
        toast.error("Couldn't remove that product. Please try again.");
      },
    });
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-3xl">Products</h1>
        <Button asChild>
          <Link href="/admin/products/new">Add Product</Link>
        </Button>
      </div>

      {isLoading && <ProductsTableSkeleton />}

      {isError && <ErrorState onRetry={() => refetch()} />}

      {!isLoading && !isError && products?.length === 0 && (
        <EmptyState
          heading="No products yet"
          message="Add your first product to see it here and on the storefront."
        />
      )}

      {!isLoading && !isError && products && products.length > 0 && (
        <table className="w-full border border-mist text-sm">
          <thead className="bg-sand">
            <tr>
              <th className="text-left px-4 py-3 font-semibold">Name</th>
              <th className="text-left px-4 py-3 font-semibold">Price</th>
              <th className="text-left px-4 py-3 font-semibold">Status</th>
              <th className="text-right px-4 py-3 font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id} className="border-t border-mist">
                <td className="px-4 py-3">{product.name}</td>
                <td className="px-4 py-3">
                  {product.price !== null ? `₹${product.price.toLocaleString("en-IN")}` : "—"}
                </td>
                <td className="px-4 py-3">
                  {product.is_active ? "Active" : "Hidden"}
                  {product.is_featured ? " · Featured" : ""}
                </td>
                <td className="px-4 py-3 text-right space-x-4">
                  <Link
                    href={`/admin/products/${product.id}/edit`}
                    className="text-brown hover:underline text-xs uppercase tracking-label"
                  >
                    Edit
                  </Link>
                  <button
                    onClick={() => setDeleteTarget({ id: product.id, name: product.name })}
                    className="text-brown hover:underline text-xs uppercase tracking-label"
                  >
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Remove this product?</DialogTitle>
            <DialogDescription>
              &ldquo;{deleteTarget?.name}&rdquo; will be hidden from the storefront. This can be
              reversed later from the database if needed — it&apos;s a soft delete, not permanent.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setDeleteTarget(null)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={confirmDelete} disabled={deleteProduct.isPending}>
              {deleteProduct.isPending ? "Removing..." : "Remove"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
