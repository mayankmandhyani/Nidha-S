"use client";

import { toast } from "sonner";
import { useAdminCategories, useToggleCategoryActive } from "@/lib/hooks/use-admin-taxonomy";
import { ErrorState } from "@/components/shared/error-state";
import { Button } from "@/components/ui/button";

function Skeleton() {
  return (
    <div className="space-y-2">
      {[...Array(3)].map((_, i) => (
        <div key={i} className="h-14 bg-sand animate-pulse motion-reduce:animate-none" />
      ))}
    </div>
  );
}

export default function AdminCategoriesPage() {
  const { data: categories, isLoading, isError, refetch } = useAdminCategories();
  const toggle = useToggleCategoryActive();

  return (
    <div>
      <h1 className="font-display text-3xl mb-2">Categories</h1>
      <p className="text-sm text-espresso/60 mb-8">
        Kurtis, Salwar Suits, and Dress Materials — the core product taxonomy every product
        belongs to exactly one of.
      </p>

      {isLoading && <Skeleton />}
      {isError && <ErrorState onRetry={() => refetch()} />}

      {!isLoading && !isError && categories && (
        <table className="w-full border border-mist text-sm">
          <thead className="bg-sand">
            <tr>
              <th className="text-left px-4 py-3 font-semibold">Name</th>
              <th className="text-left px-4 py-3 font-semibold">Slug</th>
              <th className="text-left px-4 py-3 font-semibold">Status</th>
              <th className="text-right px-4 py-3 font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id} className="border-t border-mist">
                <td className="px-4 py-3">{c.name}</td>
                <td className="px-4 py-3 text-espresso/60">{c.slug}</td>
                <td className="px-4 py-3">{c.is_active ? "Active" : "Hidden"}</td>
                <td className="px-4 py-3 text-right">
                  <Button
                    variant="secondary"
                    size="sm"
                    onClick={() =>
                      toggle.mutate(
                        { id: c.id, is_active: !c.is_active },
                        {
                          onSuccess: () => toast.success(c.is_active ? "Hidden." : "Activated."),
                          onError: () => toast.error("Couldn't update. Please try again."),
                        }
                      )
                    }
                  >
                    {c.is_active ? "Hide" : "Activate"}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <p className="text-xs text-espresso/40 mt-8">
        Adding/renaming categories is deferred — see the deferred items checklist. The three
        core categories from the brief are pre-seeded and manageable via visibility toggle.
      </p>
    </div>
  );
}
