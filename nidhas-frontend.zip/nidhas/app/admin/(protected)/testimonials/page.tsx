"use client";

import { toast } from "sonner";
import { useAdminTestimonials, useTogglePublished } from "@/lib/hooks/use-testimonials";
import { EmptyState } from "@/components/shared/empty-state";
import { ErrorState } from "@/components/shared/error-state";
import { Button } from "@/components/ui/button";

function TestimonialsSkeleton() {
  return (
    <div className="space-y-3">
      {[...Array(3)].map((_, i) => (
        <div key={i} className="h-24 bg-sand animate-pulse motion-reduce:animate-none" />
      ))}
    </div>
  );
}

export default function AdminTestimonialsPage() {
  const { data: testimonials, isLoading, isError, refetch } = useAdminTestimonials();
  const toggle = useTogglePublished();

  function handleToggle(id: string, current: boolean) {
    toggle.mutate(
      { id, is_published: !current },
      {
        onSuccess: () => toast.success(!current ? "Published." : "Unpublished."),
        onError: () => toast.error("Couldn't update. Please try again."),
      }
    );
  }

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Testimonials</h1>

      {isLoading && <TestimonialsSkeleton />}
      {isError && <ErrorState onRetry={() => refetch()} />}

      {!isLoading && !isError && testimonials?.length === 0 && (
        <EmptyState
          heading="No testimonials yet"
          message="Testimonials you add will appear here and, once published, on the homepage."
        />
      )}

      {!isLoading && !isError && testimonials && testimonials.length > 0 && (
        <div className="space-y-4">
          {testimonials.map((t) => (
            <div key={t.id} className="border border-mist p-5 flex items-start justify-between gap-4">
              <div>
                <p className="italic text-espresso/80 max-w-lg">&ldquo;{t.quote}&rdquo;</p>
                <p className="text-xs uppercase tracking-label text-brown mt-2">
                  {t.customer_name}
                  {t.location ? ` · ${t.location}` : ""}
                </p>
              </div>
              <Button
                variant={t.is_published ? "secondary" : "primary"}
                size="sm"
                onClick={() => handleToggle(t.id, t.is_published)}
                disabled={toggle.isPending}
              >
                {t.is_published ? "Unpublish" : "Publish"}
              </Button>
            </div>
          ))}
        </div>
      )}

      <p className="text-xs text-espresso/40 mt-8">
        Adding new testimonials from the admin panel is deferred to the same pass as the
        remaining content-management forms — see the deferred items checklist.
      </p>
    </div>
  );
}
