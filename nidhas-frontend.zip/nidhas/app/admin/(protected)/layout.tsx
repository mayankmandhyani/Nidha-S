import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { LogoutButton } from "@/components/admin/logout-button";
import { AdminNav } from "@/components/admin/admin-nav";

// Mock-phase session check. Real version (Phase 6 doc) reads the Supabase
// session via the server client — swapped in during Phase 15, same
// redirect-if-absent structure, so this layout barely changes shape then.
export default async function ProtectedAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const cookieStore = await cookies();
  const hasMockSession = cookieStore.get("nidhas-mock-session");

  if (!hasMockSession) {
    redirect("/admin/login");
  }

  return (
    <div className="min-h-screen grid grid-cols-[220px_1fr]">
      <aside className="border-r border-mist py-8">
        <div className="px-4 mb-8">
          <span className="font-display text-lg">Nidhas Admin</span>
        </div>
        <AdminNav />
      </aside>
      <div className="flex flex-col">
        <header className="border-b border-mist px-8 py-4 flex items-center justify-end">
          <LogoutButton />
        </header>
        <main className="p-8 flex-1 bg-ivory">{children}</main>
      </div>
    </div>
  );
}
