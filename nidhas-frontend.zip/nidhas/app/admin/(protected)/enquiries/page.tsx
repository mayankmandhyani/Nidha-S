"use client";

import { toast } from "sonner";
import { useAdminEnquiries, useUpdateEnquiryStatus } from "@/lib/hooks/use-enquiries";
import { EmptyState } from "@/components/shared/empty-state";
import { ErrorState } from "@/components/shared/error-state";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils/cn";
import type { Enquiry } from "@/types/database";

const STATUS_STYLES: Record<Enquiry["status"], string> = {
  new: "text-brown border-brown",
  contacted: "text-espresso border-mist",
  closed: "text-espresso/50 border-mist",
};

function EnquiriesSkeleton() {
  return (
    <div className="space-y-3">
      {[...Array(4)].map((_, i) => (
        <div key={i} className="h-20 bg-sand animate-pulse motion-reduce:animate-none" />
      ))}
    </div>
  );
}

export default function AdminEnquiriesPage() {
  const { data: enquiries, isLoading, isError, refetch } = useAdminEnquiries();
  const updateStatus = useUpdateEnquiryStatus();

  function handleStatusChange(id: string, status: Enquiry["status"]) {
    updateStatus.mutate(
      { id, status },
      {
        onSuccess: () => toast.success("Status updated."),
        onError: () => toast.error("Couldn't update status. Please try again."),
      }
    );
  }

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Enquiries</h1>

      {isLoading && <EnquiriesSkeleton />}
      {isError && <ErrorState onRetry={() => refetch()} />}

      {!isLoading && !isError && enquiries?.length === 0 && (
        <EmptyState
          heading="No enquiries yet"
          message="Enquiries submitted through product pages and the contact form will appear here."
        />
      )}

      {!isLoading && !isError && enquiries && enquiries.length > 0 && (
        <div className="space-y-4">
          {enquiries.map((enquiry) => (
            <div key={enquiry.id} className="border border-mist p-5">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-medium">{enquiry.customer_name}</p>
                  <p className="text-sm text-espresso/60">{enquiry.phone}</p>
                  {enquiry.email && <p className="text-sm text-espresso/60">{enquiry.email}</p>}
                  {enquiry.message && (
                    <p className="text-sm mt-2 text-espresso/80">{enquiry.message}</p>
                  )}
                  <p className="text-xs text-espresso/40 mt-2">
                    {new Date(enquiry.created_at).toLocaleString("en-IN")}
                  </p>
                </div>
                <select
                  value={enquiry.status}
                  onChange={(e) =>
                    handleStatusChange(enquiry.id, e.target.value as Enquiry["status"])
                  }
                  className={cn(
                    "border px-3 py-1 text-xs uppercase tracking-label bg-transparent",
                    STATUS_STYLES[enquiry.status]
                  )}
                >
                  <option value="new">New</option>
                  <option value="contacted">Contacted</option>
                  <option value="closed">Closed</option>
                </select>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
