"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { HeroBannerService } from "@/lib/services/hero-banner.service";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ErrorState } from "@/components/shared/error-state";
import type { HeroBanner } from "@/types/database";

function Skeleton() {
  return <div className="h-96 bg-sand animate-pulse motion-reduce:animate-none max-w-lg" />;
}

function HeroBannerForm({ banner }: { banner: HeroBanner }) {
  const queryClient = useQueryClient();
  // Initialized directly from props — no effect needed. The parent renders
  // this with `key={banner.id}` so it remounts (and re-initializes) fresh
  // whenever the underlying record actually changes.
  const [form, setForm] = useState({
    headline: banner.headline,
    subheadline: banner.subheadline ?? "",
    cta_text: banner.cta_text ?? "",
    cta_link: banner.cta_link ?? "",
  });

  const mutation = useMutation({
    mutationFn: () => HeroBannerService.update(undefined, banner.id, form),
    onSuccess: () => {
      toast.success("Hero banner updated.");
      queryClient.invalidateQueries({ queryKey: ["admin", "hero-banners"] });
    },
    onError: () => toast.error("Couldn't save. Please try again."),
  });

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        mutation.mutate();
      }}
      className="space-y-5 max-w-lg"
    >
      <div>
        <label className="text-xs uppercase tracking-label font-semibold block mb-1">
          Headline
        </label>
        <Input
          variant="boxed"
          value={form.headline}
          onChange={(e) => setForm({ ...form, headline: e.target.value })}
        />
      </div>
      <div>
        <label className="text-xs uppercase tracking-label font-semibold block mb-1">
          Subheadline
        </label>
        <Input
          variant="boxed"
          value={form.subheadline}
          onChange={(e) => setForm({ ...form, subheadline: e.target.value })}
        />
      </div>
      <div>
        <label className="text-xs uppercase tracking-label font-semibold block mb-1">
          CTA Text
        </label>
        <Input
          variant="boxed"
          value={form.cta_text}
          onChange={(e) => setForm({ ...form, cta_text: e.target.value })}
        />
      </div>
      <div>
        <label className="text-xs uppercase tracking-label font-semibold block mb-1">
          CTA Link
        </label>
        <Input
          variant="boxed"
          value={form.cta_link}
          onChange={(e) => setForm({ ...form, cta_link: e.target.value })}
        />
      </div>
      <Button type="submit" disabled={mutation.isPending}>
        {mutation.isPending ? "Saving..." : "Save Changes"}
      </Button>
    </form>
  );
}

export default function AdminHeroBannerPage() {
  const { data: banners, isLoading, isError, refetch } = useQuery({
    queryKey: ["admin", "hero-banners"],
    queryFn: () => HeroBannerService.getAllAdmin(undefined),
  });

  const banner = banners?.[0];

  return (
    <div>
      <h1 className="font-display text-3xl mb-2">Hero Banner</h1>
      <p className="text-sm text-espresso/60 mb-8 max-w-lg">
        Controls the homepage hero headline, subheadline, and call to action. Background
        image/video upload is handled during Phase 15 once Supabase Storage is connected —
        the current hero background is placeholder imagery.
      </p>

      {isLoading && <Skeleton />}
      {isError && <ErrorState onRetry={() => refetch()} />}
      {!isLoading && !isError && banner && <HeroBannerForm key={banner.id} banner={banner} />}
    </div>
  );
}
