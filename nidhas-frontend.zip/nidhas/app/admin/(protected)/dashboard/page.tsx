import { ProductService } from "@/lib/services/product.service";
import { EnquiryService } from "@/lib/services/enquiry.service";
import { TestimonialService } from "@/lib/services/testimonial.service";

export default async function DashboardPage() {
  const [products, enquiries, testimonials] = await Promise.all([
    ProductService.getAll(undefined),
    EnquiryService.getAll(undefined),
    TestimonialService.getAll(undefined),
  ]);

  const newEnquiries = enquiries.filter((e) => e.status === "new").length;

  const stats = [
    { label: "Active Products", value: products.length },
    { label: "New Enquiries", value: newEnquiries },
    { label: "Testimonials", value: testimonials.length },
  ];

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Dashboard</h1>
      <div className="grid grid-cols-3 gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className="border border-mist p-6">
            <p className="text-xs uppercase tracking-label text-brown mb-2">{stat.label}</p>
            <p className="font-display text-4xl">{stat.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
