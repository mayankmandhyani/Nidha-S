import { ContainedSection } from "@/components/storefront/section";
import { SectionEyebrow } from "@/components/shared/section-eyebrow";
import { EnquiryForm } from "@/components/storefront/enquiry-form";
import { WhatsAppButton } from "@/components/shared/whatsapp-button";
import { Reveal } from "@/components/shared/reveal";

export default function ContactPage() {
  return (
    <ContainedSection className="pt-32 max-w-xl">
      <Reveal>
        <SectionEyebrow>Get in Touch</SectionEyebrow>
        <h1 className="font-display text-4xl md:text-5xl mt-4 mb-4">Contact Us</h1>
        <p className="text-espresso/70 mb-8">
          Have a question about fabric, sizing, or a custom order? Send us a message, or
          reach us directly on WhatsApp.
        </p>
        <div className="mb-10">
          <WhatsAppButton message="Hi, I have a question about Nidhas." />
        </div>
      </Reveal>
      <Reveal delay={0.1}>
        <EnquiryForm />
      </Reveal>
    </ContainedSection>
  );
}
