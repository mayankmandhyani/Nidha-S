"use client";

import { ErrorState } from "@/components/shared/error-state";

export default function StorefrontError({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="pt-32">
      <ErrorState onRetry={reset} />
    </div>
  );
}
