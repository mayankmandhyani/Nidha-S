import { ProductService } from "@/lib/services/product.service";
import { mockStore } from "@/lib/mock-data/store";
import { ContainedSection } from "@/components/storefront/section";
import { ProductCard } from "@/components/storefront/product-card";
import { SectionEyebrow } from "@/components/shared/section-eyebrow";
import { Reveal } from "@/components/shared/reveal";

export default async function NewArrivalsPage() {
  const products = await ProductService.getNewArrivals(undefined, 20);
  const db = mockStore.get();
  const mediaByProduct = (productId: string) =>
    db.productMedia.find((m) => m.product_id === productId && m.is_primary);

  return (
    <ContainedSection className="pt-32">
      <Reveal>
        <SectionEyebrow>Just In</SectionEyebrow>
        <h1 className="font-display text-4xl md:text-5xl mt-4 mb-12">New Arrivals</h1>
      </Reveal>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
        {products.map((p, i) => (
          <Reveal key={p.id} delay={i * 0.05}>
            <ProductCard product={p} media={mediaByProduct(p.id)} />
          </Reveal>
        ))}
      </div>
    </ContainedSection>
  );
}
