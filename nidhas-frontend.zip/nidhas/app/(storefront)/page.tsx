import Image from "next/image";
import Link from "next/link";
import { ProductService } from "@/lib/services/product.service";
import { CollectionService } from "@/lib/services/collection.service";
import { TestimonialService } from "@/lib/services/testimonial.service";
import { HeroBannerService } from "@/lib/services/hero-banner.service";
import { ContentBlockService } from "@/lib/services/content-block.service";
import { mockStore } from "@/lib/mock-data/store";
import { ContainedSection, SplitSection } from "@/components/storefront/section";
import { SectionEyebrow } from "@/components/shared/section-eyebrow";
import { ProductCard } from "@/components/storefront/product-card";
import { CollectionCard } from "@/components/storefront/collection-card";
import { TestimonialCard } from "@/components/storefront/testimonial-card";
import { Reveal } from "@/components/shared/reveal";
import { Button } from "@/components/ui/button";
import { NewsletterForm } from "@/components/storefront/newsletter-form";

export default async function HomePage() {
  const [heroBanners, featuredProducts, newArrivals, collections, testimonials, brandStory, craftsmanship, whyChoose] =
    await Promise.all([
      HeroBannerService.getActive(undefined),
      ProductService.getFeatured(undefined),
      ProductService.getNewArrivals(undefined, 4),
      CollectionService.getAll(undefined),
      TestimonialService.getPublished(undefined),
      ContentBlockService.getByKey(undefined, "brand_story"),
      ContentBlockService.getByKey(undefined, "craftsmanship"),
      ContentBlockService.getByKey(undefined, "why_choose_nidhas"),
    ]);

  const hero = heroBanners[0];
  const db = mockStore.get();
  const mediaByProduct = (productId: string) =>
    db.productMedia.find((m) => m.product_id === productId && m.is_primary);

  return (
    <>
      {/* Hero */}
      <section className="relative h-screen w-full flex items-end">
        {hero?.media_path && (
          <Image
            src={hero.media_path}
            alt={hero.headline}
            fill
            priority
            className="object-cover"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-espresso/70 via-espresso/20 to-transparent" />
        <div className="relative z-10 max-w-[1440px] mx-auto px-6 md:px-12 lg:px-20 pb-24 w-full">
          <h1 className="font-display text-4xl md:text-6xl lg:text-7xl text-ivory max-w-2xl leading-tight">
            {hero?.headline ?? "Nidhas"}
          </h1>
          {hero?.subheadline && (
            <p className="mt-4 text-ivory/80 text-lg max-w-md">{hero.subheadline}</p>
          )}
          {hero?.cta_text && hero?.cta_link && (
            <Button asChild variant="primary" className="mt-8">
              <Link href={hero.cta_link}>{hero.cta_text}</Link>
            </Button>
          )}
        </div>
      </section>

      {/* Featured Collections */}
      {collections.length > 0 && (
        <ContainedSection>
          <Reveal>
            <SectionEyebrow>Featured Collection</SectionEyebrow>
            <h2 className="font-display text-3xl md:text-5xl mt-4 mb-12">
              Made for the moments that matter
            </h2>
          </Reveal>
          <div className="grid md:grid-cols-2 gap-6">
            {collections.map((c, i) => (
              <Reveal key={c.id} delay={i * 0.1}>
                <CollectionCard collection={c} />
              </Reveal>
            ))}
          </div>
        </ContainedSection>
      )}

      {/* New Arrivals */}
      <ContainedSection className="bg-sand">
        <Reveal>
          <SectionEyebrow>Just In</SectionEyebrow>
          <h2 className="font-display text-3xl md:text-5xl mt-4 mb-12">New Arrivals</h2>
        </Reveal>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          {newArrivals.map((product, i) => (
            <Reveal key={product.id} delay={i * 0.05}>
              <ProductCard product={product} media={mediaByProduct(product.id)} />
            </Reveal>
          ))}
        </div>
        <div className="text-center mt-12">
          <Button asChild variant="secondary">
            <Link href="/new-arrivals">View All New Arrivals</Link>
          </Button>
        </div>
      </ContainedSection>

      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <ContainedSection>
          <Reveal>
            <SectionEyebrow>Featured</SectionEyebrow>
            <h2 className="font-display text-3xl md:text-5xl mt-4 mb-12">
              Editors&rsquo; Selection
            </h2>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {featuredProducts.map((product, i) => (
              <Reveal key={product.id} delay={i * 0.05}>
                <ProductCard product={product} media={mediaByProduct(product.id)} />
              </Reveal>
            ))}
          </div>
        </ContainedSection>
      )}

      {/* Brand Story */}
      {brandStory && (
        <ContainedSection>
          <Reveal>
            <SplitSection
              image={
                brandStory.image_path ? (
                  <div className="aspect-[4/3] relative overflow-hidden">
                    <Image
                      src={brandStory.image_path}
                      alt={brandStory.title ?? "Brand story"}
                      fill
                      className="object-cover"
                    />
                  </div>
                ) : (
                  <div />
                )
              }
            >
              <SectionEyebrow>{brandStory.title}</SectionEyebrow>
              <p className="font-display text-2xl md:text-3xl leading-snug">{brandStory.body}</p>
            </SplitSection>
          </Reveal>
        </ContainedSection>
      )}

      {/* Craftsmanship */}
      {craftsmanship && (
        <ContainedSection className="bg-sand">
          <Reveal>
            <SplitSection
              imageFirst={false}
              image={
                craftsmanship.image_path ? (
                  <div className="aspect-[4/3] relative overflow-hidden">
                    <Image
                      src={craftsmanship.image_path}
                      alt={craftsmanship.title ?? "Craftsmanship"}
                      fill
                      className="object-cover"
                    />
                  </div>
                ) : (
                  <div />
                )
              }
            >
              <SectionEyebrow>{craftsmanship.title}</SectionEyebrow>
              <p className="font-display text-2xl md:text-3xl leading-snug">{craftsmanship.body}</p>
            </SplitSection>
          </Reveal>
        </ContainedSection>
      )}

      {/* Why Choose Nidhas */}
      {whyChoose && (
        <ContainedSection className="text-center max-w-2xl">
          <Reveal>
            <SectionEyebrow>{whyChoose.title}</SectionEyebrow>
            <p className="font-display text-2xl md:text-3xl leading-snug mt-4">
              {whyChoose.body}
            </p>
          </Reveal>
        </ContainedSection>
      )}

      {/* Testimonials */}
      {testimonials.length > 0 && (
        <ContainedSection className="bg-sand">
          <Reveal>
            <SectionEyebrow>What Customers Say</SectionEyebrow>
          </Reveal>
          <div className="grid md:grid-cols-2 gap-12 mt-8">
            {testimonials.map((t, i) => (
              <Reveal key={t.id} delay={i * 0.1}>
                <TestimonialCard testimonial={t} />
              </Reveal>
            ))}
          </div>
        </ContainedSection>
      )}

      {/* Newsletter */}
      <ContainedSection className="text-center max-w-lg">
        <Reveal>
          <h2 className="font-display text-3xl mb-4">Stay in the loop</h2>
          <p className="text-sm text-espresso/60 mb-8">
            New arrivals and festive collections, straight to your inbox.
          </p>
          <NewsletterForm />
        </Reveal>
      </ContainedSection>
    </>
  );
}
