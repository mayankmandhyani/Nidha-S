import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ProductService } from "@/lib/services/product.service";
import { mockStore } from "@/lib/mock-data/store";
import { ContainedSection } from "@/components/storefront/section";
import { ProductCard } from "@/components/storefront/product-card";
import { ProductGallery } from "@/components/storefront/product-gallery";
import { EnquiryForm } from "@/components/storefront/enquiry-form";
import { Reveal } from "@/components/shared/reveal";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const product = await ProductService.getBySlug(undefined, slug);
  if (!product) return {};

  const title = product.seo_title ?? `${product.name} — Nidhas`;
  const description =
    product.seo_description ?? product.description ?? `${product.name} from Nidhas.`;
  const primaryImage = product.media.find((m) => m.is_primary)?.storage_path;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      images: primaryImage ? [primaryImage] : [],
    },
  };
}

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const product = await ProductService.getBySlug(undefined, slug);
  if (!product) notFound();

  const db = mockStore.get();
  const relatedProducts = db.products
    .filter(
      (p) => p.category_id === product.category_id && p.id !== product.id && p.is_active && !p.deleted_at
    )
    .slice(0, 4);
  const mediaByProduct = (productId: string) =>
    db.productMedia.find((m) => m.product_id === productId && m.is_primary);

  const sizes = Array.from(new Set(product.variants.map((v) => v.size).filter(Boolean)));
  const colors = Array.from(new Set(product.variants.map((v) => v.color).filter(Boolean)));

  return (
    <ContainedSection className="pt-32">
      {/* Breadcrumb */}
      <nav className="text-xs uppercase tracking-label text-espresso/50 mb-8 flex gap-2">
        <Link href="/" className="hover:text-brown">Home</Link>
        <span>/</span>
        <Link href={`/collections/${product.category.slug}`} className="hover:text-brown">
          {product.category.name}
        </Link>
        <span>/</span>
        <span className="text-espresso">{product.name}</span>
      </nav>

      <div className="grid md:grid-cols-2 gap-12 md:gap-16">
        <ProductGallery media={product.media} productName={product.name} />

        <div>
          <h1 className="font-display text-3xl md:text-4xl">{product.name}</h1>
          {product.price !== null ? (
            <p className="mt-3 text-lg text-espresso/70">
              ₹{product.price.toLocaleString("en-IN")}
            </p>
          ) : (
            <p className="mt-3 text-xs uppercase tracking-label text-brown">Enquire for price</p>
          )}

          {product.description && (
            <p className="mt-6 text-espresso/80 leading-relaxed">{product.description}</p>
          )}

          {product.fabric_details && (
            <div className="mt-6">
              <p className="text-xs uppercase tracking-label text-brown mb-1">Fabric</p>
              <p className="text-sm">{product.fabric_details}</p>
            </div>
          )}

          {sizes.length > 0 && (
            <div className="mt-6">
              <p className="text-xs uppercase tracking-label text-brown mb-2">Available Sizes</p>
              <div className="flex gap-2">
                {sizes.map((s) => (
                  <span key={s} className="border border-mist px-3 py-1 text-sm">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          )}

          {colors.length > 0 && (
            <div className="mt-4">
              <p className="text-xs uppercase tracking-label text-brown mb-2">Available Colors</p>
              <div className="flex gap-2">
                {colors.map((c) => (
                  <span key={c} className="border border-mist px-3 py-1 text-sm">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="mt-10 border-t border-mist pt-8">
            <p className="text-xs uppercase tracking-label text-brown mb-4">
              Interested in this piece?
            </p>
            <EnquiryForm productId={product.id} productName={product.name} />
          </div>
        </div>
      </div>

      {relatedProducts.length > 0 && (
        <div className="mt-32">
          <Reveal>
            <h2 className="font-display text-2xl md:text-3xl mb-8">You may also like</h2>
          </Reveal>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {relatedProducts.map((p, i) => (
              <Reveal key={p.id} delay={i * 0.05}>
                <ProductCard product={p} media={mediaByProduct(p.id)} />
              </Reveal>
            ))}
          </div>
        </div>
      )}
    </ContainedSection>
  );
}
