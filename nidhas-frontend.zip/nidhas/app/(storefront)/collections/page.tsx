import { CategoryService } from "@/lib/services/category.service";
import { CollectionService } from "@/lib/services/collection.service";
import { ContainedSection } from "@/components/storefront/section";
import { CollectionCard } from "@/components/storefront/collection-card";
import { SectionEyebrow } from "@/components/shared/section-eyebrow";
import { Reveal } from "@/components/shared/reveal";
import Link from "next/link";

export default async function CollectionsIndexPage() {
  const [categories, collections] = await Promise.all([
    CategoryService.getAll(undefined),
    CollectionService.getAll(undefined),
  ]);

  return (
    <ContainedSection className="pt-32">
      <Reveal>
        <SectionEyebrow>Browse</SectionEyebrow>
        <h1 className="font-display text-4xl md:text-5xl mt-4 mb-12">Collections</h1>
      </Reveal>

      {collections.length > 0 && (
        <div className="grid md:grid-cols-2 gap-6 mb-16">
          {collections.map((c, i) => (
            <Reveal key={c.id} delay={i * 0.1}>
              <CollectionCard collection={c} />
            </Reveal>
          ))}
        </div>
      )}

      <Reveal>
        <h2 className="font-display text-2xl mb-6">Shop by Category</h2>
      </Reveal>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {categories.map((c, i) => (
          <Reveal key={c.id} delay={i * 0.05}>
            <Link
              href={`/collections/${c.slug}`}
              className="block border border-mist p-8 text-center hover:border-espresso transition-colors"
            >
              <h3 className="font-display text-xl">{c.name}</h3>
            </Link>
          </Reveal>
        ))}
      </div>
    </ContainedSection>
  );
}
