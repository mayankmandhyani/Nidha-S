import { notFound } from "next/navigation";
import { CategoryService } from "@/lib/services/category.service";
import { CollectionService } from "@/lib/services/collection.service";
import { ProductService } from "@/lib/services/product.service";
import { mockStore } from "@/lib/mock-data/store";
import { ContainedSection } from "@/components/storefront/section";
import { ProductCard } from "@/components/storefront/product-card";
import { SectionEyebrow } from "@/components/shared/section-eyebrow";
import { EmptyState } from "@/components/shared/empty-state";
import { Reveal } from "@/components/shared/reveal";

interface Props {
  params: Promise<{ slug: string }>;
}

export default async function CollectionOrCategoryPage({ params }: Props) {
  const { slug } = await params;

  // A slug may match either a category (Kurtis, Salwar Suits...) or a
  // curated collection (Festive Collection) — both render the same layout.
  const [category, collection] = await Promise.all([
    CategoryService.getBySlug(undefined, slug),
    CollectionService.getBySlug(undefined, slug),
  ]);

  const entity = category ?? collection;
  if (!entity) notFound();

  const products = category
    ? await ProductService.getByCategorySlug(undefined, slug)
    : await ProductService.getByCollectionSlug(undefined, slug);

  const db = mockStore.get();
  const mediaByProduct = (productId: string) =>
    db.productMedia.find((m) => m.product_id === productId && m.is_primary);

  return (
    <ContainedSection className="pt-32">
      <Reveal>
        <SectionEyebrow>{category ? "Category" : "Collection"}</SectionEyebrow>
        <h1 className="font-display text-4xl md:text-5xl mt-4 mb-4">{entity.name}</h1>
        {entity.description && (
          <p className="text-espresso/70 max-w-xl mb-12">{entity.description}</p>
        )}
      </Reveal>

      {products.length === 0 ? (
        <EmptyState
          heading="No products match your filters"
          message="Try browsing the full collection instead."
        />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
          {products.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.05}>
              <ProductCard product={p} media={mediaByProduct(p.id)} />
            </Reveal>
          ))}
        </div>
      )}
    </ContainedSection>
  );
}
