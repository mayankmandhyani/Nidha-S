import Image from "next/image";
import { ContentBlockService } from "@/lib/services/content-block.service";
import { ContainedSection, SplitSection } from "@/components/storefront/section";
import { SectionEyebrow } from "@/components/shared/section-eyebrow";
import { Reveal } from "@/components/shared/reveal";

export default async function AboutPage() {
  const blocks = await ContentBlockService.getAll(undefined);

  return (
    <ContainedSection className="pt-32 space-y-24">
      <Reveal>
        <SectionEyebrow>About Nidhas</SectionEyebrow>
        <h1 className="font-display text-4xl md:text-5xl mt-4 max-w-2xl">
          Made with intention, not mass-produced
        </h1>
      </Reveal>

      {blocks.map((block, i) => (
        <Reveal key={block.id} delay={i * 0.1}>
          <SplitSection
            imageFirst={i % 2 === 0}
            image={
              block.image_path ? (
                <div className="aspect-[4/3] relative overflow-hidden">
                  <Image
                    src={block.image_path}
                    alt={block.title ?? ""}
                    fill
                    className="object-cover"
                  />
                </div>
              ) : (
                <div />
              )
            }
          >
            <SectionEyebrow>{block.title}</SectionEyebrow>
            <p className="font-display text-2xl md:text-3xl leading-snug">{block.body}</p>
          </SplitSection>
        </Reveal>
      ))}
    </ContainedSection>
  );
}
