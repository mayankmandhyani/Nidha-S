import { seedData } from "./seed";
import type {
  Product,
  Category,
  Collection,
  ProductCollection,
  ProductVariant,
  ProductMedia,
  Testimonial,
  Enquiry,
  HeroBanner,
  ContentBlock,
} from "@/types/database";

const STORAGE_KEY = "nidhas-mock-db";

export interface MockDB {
  products: Product[];
  categories: Category[];
  collections: Collection[];
  productCollections: ProductCollection[];
  productVariants: ProductVariant[];
  productMedia: ProductMedia[];
  testimonials: Testimonial[];
  enquiries: Enquiry[];
  heroBanners: HeroBanner[];
  contentBlocks: ContentBlock[];
}

function loadStore(): MockDB {
  // Server Components have no localStorage — always fall back to seed data
  // there. This is a known, accepted limitation of the mock-data phase (see
  // docs/journal.md): admin edits are visible client-side within a session
  // but don't survive a hard refresh on server-rendered pages. Resolves
  // automatically once Phase 15 replaces this with a real database.
  if (typeof window === "undefined") return seedData;

  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (!stored) return seedData;

  try {
    return JSON.parse(stored) as MockDB;
  } catch {
    return seedData;
  }
}

function saveStore(db: MockDB) {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  }
}

export const mockStore = {
  get: loadStore,
  save: saveStore,
  reset: () => saveStore(seedData),
};

// Artificial latency so loading states are actually visible and testable.
// Set to 0 during rapid iteration if it gets in the way.
export function mockDelay(ms = 350) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
