/**
 * Placeholder for the real Supabase client type.
 * During the mock-data phase, no @supabase/supabase-js dependency is installed —
 * every service function still accepts a `client` parameter (per the DI pattern
 * in docs/architecture.md) so call sites never change when Phase 15 backend
 * integration swaps this for the real `SupabaseClient` type and installs the
 * actual package.
 */
export type SupabaseClient = unknown;
