import type { SupabaseClient } from "@/lib/supabase/types";
import { mockStore, mockDelay } from "@/lib/mock-data/store";
import type { Collection } from "@/types/database";

export const CollectionService = {
  async getAll(client: SupabaseClient): Promise<Collection[]> {
    await mockDelay();
    return mockStore
      .get()
      .collections.filter((c) => c.is_active)
      .sort((a, b) => a.display_order - b.display_order);
  },

  async getAllAdmin(client: SupabaseClient): Promise<Collection[]> {
    await mockDelay();
    return mockStore.get().collections.sort((a, b) => a.display_order - b.display_order);
  },

  async getBySlug(client: SupabaseClient, slug: string): Promise<Collection | null> {
    await mockDelay();
    return (
      mockStore.get().collections.find((c) => c.slug.toLowerCase() === slug.toLowerCase()) ?? null
    );
  },

  async toggleActive(client: SupabaseClient, id: string, is_active: boolean): Promise<Collection> {
    await mockDelay();
    const db = mockStore.get();
    const index = db.collections.findIndex((c) => c.id === id);
    if (index === -1) throw new Error("Collection not found");
    db.collections[index] = { ...db.collections[index], is_active, updated_at: new Date().toISOString() };
    mockStore.save(db);
    return db.collections[index];
  },
};
