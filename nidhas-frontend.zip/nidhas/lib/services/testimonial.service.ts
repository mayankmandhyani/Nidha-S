import type { SupabaseClient } from "@/lib/supabase/types";
import { mockStore, mockDelay } from "@/lib/mock-data/store";
import type { Testimonial } from "@/types/database";

export const TestimonialService = {
  async getPublished(client: SupabaseClient): Promise<Testimonial[]> {
    await mockDelay();
    return mockStore
      .get()
      .testimonials.filter((t) => t.is_published)
      .sort((a, b) => a.display_order - b.display_order);
  },

  async getAll(client: SupabaseClient): Promise<Testimonial[]> {
    await mockDelay();
    return mockStore.get().testimonials.sort((a, b) => a.display_order - b.display_order);
  },

  async togglePublished(
    client: SupabaseClient,
    id: string,
    is_published: boolean
  ): Promise<Testimonial> {
    await mockDelay();
    const db = mockStore.get();
    const index = db.testimonials.findIndex((t) => t.id === id);
    if (index === -1) throw new Error("Testimonial not found");
    db.testimonials[index] = {
      ...db.testimonials[index],
      is_published,
      updated_at: new Date().toISOString(),
    };
    mockStore.save(db);
    return db.testimonials[index];
  },
};
