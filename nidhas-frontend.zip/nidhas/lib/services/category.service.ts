import type { SupabaseClient } from "@/lib/supabase/types";
import { mockStore, mockDelay } from "@/lib/mock-data/store";
import type { Category } from "@/types/database";

export const CategoryService = {
  async getAll(client: SupabaseClient): Promise<Category[]> {
    await mockDelay();
    return mockStore
      .get()
      .categories.filter((c) => c.is_active)
      .sort((a, b) => a.display_order - b.display_order);
  },

  async getAllAdmin(client: SupabaseClient): Promise<Category[]> {
    await mockDelay();
    return mockStore.get().categories.sort((a, b) => a.display_order - b.display_order);
  },

  async getBySlug(client: SupabaseClient, slug: string): Promise<Category | null> {
    await mockDelay();
    return (
      mockStore.get().categories.find((c) => c.slug.toLowerCase() === slug.toLowerCase()) ?? null
    );
  },

  async toggleActive(client: SupabaseClient, id: string, is_active: boolean): Promise<Category> {
    await mockDelay();
    const db = mockStore.get();
    const index = db.categories.findIndex((c) => c.id === id);
    if (index === -1) throw new Error("Category not found");
    db.categories[index] = { ...db.categories[index], is_active, updated_at: new Date().toISOString() };
    mockStore.save(db);
    return db.categories[index];
  },
};
