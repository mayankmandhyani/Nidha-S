import type { SupabaseClient } from "@/lib/supabase/types";

// Deliberately trivial per client direction: this is a development-only demo
// gate, not a security boundary — there's no real backend or real data behind
// it yet to protect. No fake User object, no session realism. The interface
// shape (client param, signIn/signOut) matches the real Supabase-backed
// version that replaces this in Phase 15, so callers never change.
const MOCK_SESSION_COOKIE = "nidhas-mock-session";
const DEMO_PASSWORD = "nidhas-demo"; // not a real secret — see note above

export const AuthService = {
  async signIn(client: SupabaseClient, credentials: { email: string; password: string }) {
    await new Promise((r) => setTimeout(r, 300));
    if (credentials.password !== DEMO_PASSWORD) {
      throw new Error("Invalid email or password.");
    }
    document.cookie = `${MOCK_SESSION_COOKIE}=true; path=/`;
  },

  async signOut(client: SupabaseClient) {
    document.cookie = `${MOCK_SESSION_COOKIE}=; path=/; max-age=0`;
  },
};
