import type { SupabaseClient } from "@/lib/supabase/types";
import { mockStore, mockDelay } from "@/lib/mock-data/store";
import type { Product, ProductWithMedia } from "@/types/database";

type ProductInput = Omit<Product, "id" | "created_at" | "updated_at" | "deleted_at">;

export const ProductService = {
  async getAll(client: SupabaseClient): Promise<Product[]> {
    await mockDelay();
    return mockStore
      .get()
      .products.filter((p) => p.is_active && !p.deleted_at)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  async getFeatured(client: SupabaseClient): Promise<Product[]> {
    await mockDelay();
    return mockStore.get().products.filter((p) => p.is_featured && p.is_active && !p.deleted_at);
  },

  async getNewArrivals(client: SupabaseClient, limit = 8): Promise<Product[]> {
    await mockDelay();
    return mockStore
      .get()
      .products.filter((p) => p.is_active && !p.deleted_at)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limit);
  },

  async getByCategorySlug(client: SupabaseClient, categorySlug: string): Promise<Product[]> {
    await mockDelay();
    const db = mockStore.get();
    const category = db.categories.find((c) => c.slug.toLowerCase() === categorySlug.toLowerCase());
    if (!category) return [];
    return db.products.filter(
      (p) => p.category_id === category.id && p.is_active && !p.deleted_at
    );
  },

  async getByCollectionSlug(client: SupabaseClient, collectionSlug: string): Promise<Product[]> {
    await mockDelay();
    const db = mockStore.get();
    const collection = db.collections.find(
      (c) => c.slug.toLowerCase() === collectionSlug.toLowerCase()
    );
    if (!collection) return [];
    const productIds = db.productCollections
      .filter((pc) => pc.collection_id === collection.id)
      .map((pc) => pc.product_id);
    return db.products.filter(
      (p) => productIds.includes(p.id) && p.is_active && !p.deleted_at
    );
  },

  async getBySlug(client: SupabaseClient, slug: string): Promise<ProductWithMedia | null> {
    await mockDelay();
    const db = mockStore.get();
    const product = db.products.find(
      (p) => p.slug.toLowerCase() === slug.toLowerCase() && p.is_active && !p.deleted_at
    );
    if (!product) return null;

    const category = db.categories.find((c) => c.id === product.category_id);
    if (!category) return null;

    return {
      ...product,
      category,
      media: db.productMedia
        .filter((m) => m.product_id === product.id)
        .sort((a, b) => a.display_order - b.display_order),
      variants: db.productVariants.filter((v) => v.product_id === product.id),
    };
  },

  async create(client: SupabaseClient, data: ProductInput): Promise<Product> {
    await mockDelay();
    const db = mockStore.get();
    const newProduct: Product = {
      ...data,
      id: crypto.randomUUID(),
      deleted_at: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    db.products.push(newProduct);
    mockStore.save(db);
    return newProduct;
  },

  async update(client: SupabaseClient, id: string, data: Partial<ProductInput>): Promise<Product> {
    await mockDelay();
    const db = mockStore.get();
    const index = db.products.findIndex((p) => p.id === id);
    if (index === -1) throw new Error("Product not found");
    db.products[index] = {
      ...db.products[index],
      ...data,
      updated_at: new Date().toISOString(),
    };
    mockStore.save(db);
    return db.products[index];
  },

  async softDelete(client: SupabaseClient, id: string): Promise<void> {
    await mockDelay();
    const db = mockStore.get();
    const index = db.products.findIndex((p) => p.id === id);
    if (index === -1) throw new Error("Product not found");
    db.products[index].deleted_at = new Date().toISOString();
    mockStore.save(db);
  },
};
