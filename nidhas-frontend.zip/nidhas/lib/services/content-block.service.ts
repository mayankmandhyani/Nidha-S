import type { SupabaseClient } from "@/lib/supabase/types";
import { mockStore, mockDelay } from "@/lib/mock-data/store";
import type { ContentBlock } from "@/types/database";

export const ContentBlockService = {
  async getByKey(client: SupabaseClient, blockKey: string): Promise<ContentBlock | null> {
    await mockDelay();
    return (
      mockStore.get().contentBlocks.find((b) => b.block_key === blockKey && b.is_published) ??
      null
    );
  },

  async getAll(client: SupabaseClient): Promise<ContentBlock[]> {
    await mockDelay();
    return mockStore.get().contentBlocks.sort((a, b) => a.display_order - b.display_order);
  },

  async update(
    client: SupabaseClient,
    id: string,
    data: Partial<Pick<ContentBlock, "title" | "body" | "is_published">>
  ): Promise<ContentBlock> {
    await mockDelay();
    const db = mockStore.get();
    const index = db.contentBlocks.findIndex((b) => b.id === id);
    if (index === -1) throw new Error("Content block not found");
    db.contentBlocks[index] = { ...db.contentBlocks[index], ...data, updated_at: new Date().toISOString() };
    mockStore.save(db);
    return db.contentBlocks[index];
  },
};
