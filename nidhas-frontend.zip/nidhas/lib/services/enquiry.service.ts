import type { SupabaseClient } from "@/lib/supabase/types";
import { mockStore, mockDelay } from "@/lib/mock-data/store";
import type { Enquiry } from "@/types/database";

type EnquiryInput = Omit<Enquiry, "id" | "status" | "created_at" | "updated_at">;

export const EnquiryService = {
  async create(client: SupabaseClient, data: EnquiryInput): Promise<Enquiry> {
    await mockDelay();
    const db = mockStore.get();
    const newEnquiry: Enquiry = {
      ...data,
      id: crypto.randomUUID(),
      status: "new",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    db.enquiries.push(newEnquiry);
    mockStore.save(db);
    return newEnquiry;
  },

  async getAll(client: SupabaseClient): Promise<Enquiry[]> {
    await mockDelay();
    return mockStore
      .get()
      .enquiries.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  async updateStatus(
    client: SupabaseClient,
    id: string,
    status: Enquiry["status"]
  ): Promise<Enquiry> {
    await mockDelay();
    const db = mockStore.get();
    const index = db.enquiries.findIndex((e) => e.id === id);
    if (index === -1) throw new Error("Enquiry not found");
    db.enquiries[index] = { ...db.enquiries[index], status, updated_at: new Date().toISOString() };
    mockStore.save(db);
    return db.enquiries[index];
  },
};
