import type { SupabaseClient } from "@/lib/supabase/types";
import { mockStore, mockDelay } from "@/lib/mock-data/store";
import type { HeroBanner } from "@/types/database";

export const HeroBannerService = {
  async getActive(client: SupabaseClient): Promise<HeroBanner[]> {
    await mockDelay();
    return mockStore
      .get()
      .heroBanners.filter((h) => h.is_active)
      .sort((a, b) => a.display_order - b.display_order);
  },

  async getAllAdmin(client: SupabaseClient): Promise<HeroBanner[]> {
    await mockDelay();
    return mockStore.get().heroBanners.sort((a, b) => a.display_order - b.display_order);
  },

  async update(
    client: SupabaseClient,
    id: string,
    data: Partial<Pick<HeroBanner, "headline" | "subheadline" | "cta_text" | "cta_link" | "open_in_new_tab">>
  ): Promise<HeroBanner> {
    await mockDelay();
    const db = mockStore.get();
    const index = db.heroBanners.findIndex((h) => h.id === id);
    if (index === -1) throw new Error("Hero banner not found");
    db.heroBanners[index] = { ...db.heroBanners[index], ...data, updated_at: new Date().toISOString() };
    mockStore.save(db);
    return db.heroBanners[index];
  },
};
