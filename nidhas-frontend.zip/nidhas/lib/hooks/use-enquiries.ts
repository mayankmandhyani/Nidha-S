"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { EnquiryService } from "@/lib/services/enquiry.service";
import type { Enquiry } from "@/types/database";

export function useAdminEnquiries() {
  return useQuery({
    queryKey: ["admin", "enquiries"],
    queryFn: () => EnquiryService.getAll(undefined),
  });
}

export function useUpdateEnquiryStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status }: { id: string; status: Enquiry["status"] }) =>
      EnquiryService.updateStatus(undefined, id, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "enquiries"] });
    },
  });
}
