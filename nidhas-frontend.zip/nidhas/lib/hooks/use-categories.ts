"use client";

import { useQuery } from "@tanstack/react-query";
import { CategoryService } from "@/lib/services/category.service";

export function useCategories() {
  return useQuery({
    queryKey: ["categories"],
    queryFn: () => CategoryService.getAll(undefined),
  });
}
