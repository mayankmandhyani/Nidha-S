"use client";

import { useSyncExternalStore } from "react";

// useSyncExternalStore, not useState+useEffect — the correct React pattern
// for subscribing to an external browser API (matchMedia) without an
// unnecessary extra render or a setState-in-effect anti-pattern.
function subscribe(callback: () => void) {
  const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
  mq.addEventListener("change", callback);
  return () => mq.removeEventListener("change", callback);
}

function getSnapshot() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function getServerSnapshot() {
  return false;
}

export function useReducedMotion() {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}
