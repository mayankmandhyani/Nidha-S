"use client";

import { useMutation } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { AuthService } from "@/lib/services/auth.service";
import type { LoginInput } from "@/lib/validators/auth.schema";

export function useSignIn() {
  const router = useRouter();

  return useMutation({
    mutationFn: (credentials: LoginInput) => AuthService.signIn(undefined, credentials),
    onSuccess: () => {
      router.push("/admin/dashboard");
      router.refresh();
    },
  });
}

export function useSignOut() {
  const router = useRouter();

  return useMutation({
    mutationFn: () => AuthService.signOut(undefined),
    onSuccess: () => {
      router.push("/admin/login");
      router.refresh();
    },
  });
}
