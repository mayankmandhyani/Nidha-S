"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CategoryService } from "@/lib/services/category.service";
import { CollectionService } from "@/lib/services/collection.service";

export function useAdminCategories() {
  return useQuery({
    queryKey: ["admin", "categories"],
    queryFn: () => CategoryService.getAllAdmin(undefined),
  });
}

export function useToggleCategoryActive() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, is_active }: { id: string; is_active: boolean }) =>
      CategoryService.toggleActive(undefined, id, is_active),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin", "categories"] }),
  });
}

export function useAdminCollections() {
  return useQuery({
    queryKey: ["admin", "collections"],
    queryFn: () => CollectionService.getAllAdmin(undefined),
  });
}

export function useToggleCollectionActive() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, is_active }: { id: string; is_active: boolean }) =>
      CollectionService.toggleActive(undefined, id, is_active),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin", "collections"] }),
  });
}
