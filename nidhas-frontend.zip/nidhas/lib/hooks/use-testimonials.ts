"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { TestimonialService } from "@/lib/services/testimonial.service";

export function useAdminTestimonials() {
  return useQuery({
    queryKey: ["admin", "testimonials"],
    queryFn: () => TestimonialService.getAll(undefined),
  });
}

export function useTogglePublished() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, is_published }: { id: string; is_published: boolean }) =>
      TestimonialService.togglePublished(undefined, id, is_published),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "testimonials"] });
    },
  });
}
