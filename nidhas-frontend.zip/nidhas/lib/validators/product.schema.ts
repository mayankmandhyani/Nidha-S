import { z } from "zod";

export const productSchema = z.object({
  category_id: z.string().min(1, "Category is required"),
  name: z.string().min(1, "Name is required"),
  slug: z
    .string()
    .min(1, "Slug is required")
    .regex(/^[a-z0-9-]+$/, "Slug can only contain lowercase letters, numbers, and hyphens"),
  description: z.string().optional(),
  fabric_details: z.string().optional(),
  price: z.coerce.number().positive().nullable().optional(),
  is_active: z.boolean(),
  is_featured: z.boolean(),
  seo_title: z.string().optional(),
  seo_description: z.string().optional(),
});

export type ProductInput = z.infer<typeof productSchema>;
