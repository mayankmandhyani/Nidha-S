import { z } from "zod";

export const enquirySchema = z.object({
  customer_name: z.string().min(1, "Name is required"),
  phone: z
    .string()
    .min(8, "Enter a valid phone number")
    .max(20, "Enter a valid phone number"),
  email: z.string().email("Enter a valid email address").optional().or(z.literal("")),
  message: z.string().optional(),
  product_id: z.string().nullable().optional(),
});

export type EnquiryInput = z.infer<typeof enquirySchema>;
