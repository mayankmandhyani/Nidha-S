# Nidhas — Project Status

## Verification (as of this build)

```
✓ npm run build    — clean, zero errors, 19/19 routes generated
✓ npx eslint .     — zero errors, zero warnings
✓ Dev server smoke test — homepage, product page, collections, contact,
  admin login all return 200; /admin/dashboard correctly 307-redirects
  to /admin/login with no session (proxy.ts confirmed executing)
```

76 TypeScript/TSX files across the approved folder structure.

---

## Fully built

**Public site**
- Homepage — hero, featured collections, new arrivals, featured products, brand story, craftsmanship, why-choose-us, testimonials, newsletter form
- Collections index + individual collection/category pages (shared layout, handles both taxonomies)
- Product detail — gallery with thumbnail switching, sizes/colors from variants, fabric details, price-or-enquire-CTA logic, related products, breadcrumb, `generateMetadata` for per-product OG tags
- New Arrivals (computed by recency, not a stored collection — per the Phase 5 design decision)
- About (renders all content blocks)
- Contact (enquiry form, WhatsApp button)
- 404 page, storefront error boundary

**Admin panel**
- Mock login gate + protected route group (`(protected)`), session-checked server-side via `proxy.ts` and the layout together
- Dashboard (live counts from mock data)
- Products — full CRUD: list with skeleton/empty/error states, create, edit, soft-delete with confirmation dialog
- Enquiries — inbox with status management (new/contacted/closed)
- Testimonials — list with publish/unpublish toggle
- Categories, Collections — list with active/hidden toggle
- Hero Banner — editable headline/subheadline/CTA
- Homepage Content — editable title/body per content block (this is the literal DB-backed replacement for the `content/` static files, per the migration rule in the folder structure doc)

**Design system**
- Full color/type/spacing token set implemented via Tailwind v4 `@theme`
- Button (3 variants), Input/Textarea (underline + boxed treatments), Badge, Dialog, Form components — all hand-built and re-themed, not default shadcn output
- Section wrappers (FullBleed/Contained/Split), ProductCard/CollectionCard/TestimonialCard, skeletons matching real content proportions, consistent empty/error state pattern
- Scroll-reveal (`Reveal`) and reduced-motion handling (`useSyncExternalStore`-based hook) used throughout
- Responsive: every page uses the grid/breakpoint conventions from the design system (2/3/4-column product grids, stacking split-sections below `md`, mobile full-screen nav overlay)

**Mock data architecture**
- `types/database.ts` hand-matched to the finalized Phase 5 schema
- `lib/mock-data/seed.ts` — realistic fixture content (not lorem ipsum) across all 6 products, 3 categories, 1 collection, 2 testimonials, 1 hero banner, 3 content blocks
- `lib/mock-data/store.ts` — localStorage-backed, seed-fallback for SSR
- Every service in `lib/services/` follows the DI pattern (client param accepted, unused during mock phase) — verified consistent; one violation I introduced myself (testimonials hook touching the store directly) was caught and fixed during the build
- Mock auth: deliberately trivial per your direction — no fake session realism, single hardcoded password check, clearly commented as a demo gate with zero real security value

---

## Deferred (as scoped — only these two categories)

**1. Supabase integration** (unchanged from the roadmap — executes the already-designed Phase 4/5/6 documents, not redesigned):
- Create the real Supabase project, run the finalized schema, configure real Storage buckets
- Swap every mock service's internals for real Supabase calls (signatures unchanged — this is the one-line-per-function swap the DI pattern was built for)
- Restore the real `proxy.ts` (session-based, from the Phase 4/6 docs) in place of the mock-cookie stub
- Replace `lib/mock-data/` entirely; remove it once the swap is verified
- Real product image/video upload via Storage, replacing picsum placeholder imagery

**2. Post-approval polish** (explicitly deferred per your Phase 7 direction, not forgotten):
- Final signature-motion decision (the gold underline exists as a component, unused as a defining element — revisit once real logo/photography exist together)
- Full cross-device responsive QA pass (built responsive throughout, but not yet manually walked on real devices/browser devtools at every breakpoint)
- Admin forms for *creating* new categories, collections, and testimonials (currently: visibility toggle only for categories/collections, publish toggle for testimonials — add/edit forms for these three follow the same pattern as the product form, just not yet built out)
- Real Instagram gallery integration (homepage currently doesn't include this section — brief lists it, worth confirming scope before building against a real Instagram API or a simpler static grid)
- Accessibility pass with actual screen reader / keyboard-only testing (built to the Part S rules from the design system doc, not yet manually verified)

---

## Honest gaps worth naming, not hiding

- **Product image/video/360° upload UI** doesn't exist yet in the admin panel — products are seeded with fixed picsum placeholder images, not uploadable through the mock admin. This is consistent with "no Storage integration yet," but worth being explicit: you can't add new product photos through the UI right now, only through editing `seed.ts` directly.
- **`sonner` toast styling** uses inline styles rather than Tailwind classes (sonner's API works better with the `style` prop for full control) — functionally correct, just a different styling mechanism than the rest of the codebase, worth knowing if you go looking for it in `tailwind.config`-style overrides that don't exist for it.
- **The `(protected)` route group restructuring** flagged back in the Phase 6 doc is implemented — `app/admin/(protected)/` holds every session-gated page, `app/admin/login` sits outside it. This resolved the header-passing workaround discussed then.

---

## Next steps, in order

1. `npm install && npm run dev` locally, walk through both the storefront and admin panel yourself
2. Push to GitHub
3. Deploy to Vercel (no environment variables needed for this phase)
4. Get client (your uncle's) sign-off on the live demo
5. Only then: backend integration, executing the existing Phase 4/5/6 documents
