import { NextResponse, type NextRequest } from "next/server";

// Mock-phase stub (Next.js 16 proxy.ts convention, formerly middleware.ts). The real Supabase-backed version (session check via
// supabase.auth.getUser()) is preserved unchanged in nidhas-phase4-supabase-setup.md
// and gets swapped back in verbatim during Phase 15 backend integration — not
// rewritten from scratch.
export function proxy(request: NextRequest) {
  const isAdminRoute = request.nextUrl.pathname.startsWith("/admin");
  const isLoginRoute = request.nextUrl.pathname === "/admin/login";
  const hasMockSession = request.cookies.get("nidhas-mock-session");

  if (isAdminRoute && !isLoginRoute && !hasMockSession) {
    const url = request.nextUrl.clone();
    url.pathname = "/admin/login";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*"],
};
